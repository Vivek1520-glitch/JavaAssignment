package com.aurionpro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.CustomerProfileCompletionDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;
import com.aurionpro.dto.PendingCustomerResponseDTO;
import com.aurionpro.service.CustomerServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

	@Autowired
	private CustomerServiceImpl customerService;

	@PostMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<CustomerResponseDTO> createCustomer(
			@Valid @RequestBody CustomerRequestDTO customerRequestDTO) {
		CustomerResponseDTO createdCustomer = customerService.createCustomer(customerRequestDTO);
		return ResponseEntity.ok(createdCustomer);
	}

	@PostMapping("/complete-profile")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<CustomerResponseDTO> completeCustomerProfile(
			@Valid @RequestBody CustomerProfileCompletionDTO dto) {
		CustomerResponseDTO completedCustomer = customerService.completeCustomerProfile(dto);
		return ResponseEntity.ok(completedCustomer);
	}

	@GetMapping("/pending")
	@PreAuthorize("hasRole('ADMIN')")

	public ResponseEntity<List<PendingCustomerResponseDTO>> getPendingCustomers() {
		List<PendingCustomerResponseDTO> pendingCustomers = customerService.getPendingCustomers();
		return ResponseEntity.ok(pendingCustomers);
	}

	@GetMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and @customerService.isCustomerOwner(#id, authentication.name))")
	public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable Long id, Authentication authentication) {
		CustomerResponseDTO customer = customerService.getCustomerById(id);
		return ResponseEntity.ok(customer);
	}

	@GetMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {
		List<CustomerResponseDTO> customers = customerService.getAllCustomers();
		return ResponseEntity.ok(customers);
	}

	@PatchMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and @customerService.isCustomerOwner(#id, authentication.name))")
	public ResponseEntity<CustomerResponseDTO> updateCustomer(@PathVariable Long id,
			@Valid @RequestBody CustomerUpdateDTO customerUpdateDTO, Authentication authentication) {
		CustomerResponseDTO updatedCustomer = customerService.updateCustomer(id, customerUpdateDTO);
		return ResponseEntity.ok(updatedCustomer);
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
		customerService.deleteCustomer(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/my-profile")
	@PreAuthorize("hasRole('CUSTOMER')")
	public ResponseEntity<CustomerResponseDTO> getMyProfile(Authentication authentication) {
		CustomerResponseDTO customer = customerService.getCustomerByUsername(authentication.getName());
		return ResponseEntity.ok(customer);
	}

	@PatchMapping("/my-profile")
	@PreAuthorize("hasRole('CUSTOMER')")
	public ResponseEntity<CustomerResponseDTO> updateMyProfile(@Valid @RequestBody CustomerUpdateDTO customerUpdateDTO,
			Authentication authentication) {
		CustomerResponseDTO updatedCustomer = customerService.updateCustomerByUsername(authentication.getName(),
				customerUpdateDTO);
		return ResponseEntity.ok(updatedCustomer);
	}

}