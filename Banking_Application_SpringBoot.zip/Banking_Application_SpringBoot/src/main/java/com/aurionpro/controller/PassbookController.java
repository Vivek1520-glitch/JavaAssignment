


package com.aurionpro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.PassbookRequestDTO;
import com.aurionpro.dto.PassbookRequestOptionalDTO;
import com.aurionpro.dto.PassbookResponseDTO;
import com.aurionpro.service.PassbookService;
import com.aurionpro.service.EmailService;
import com.aurionpro.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/passbook")
@CrossOrigin(origins = "*")
public class PassbookController {

    @Autowired
    private PassbookService passbookService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private CustomerService customerService;

    @PostMapping("/get")
    @PreAuthorize("hasRole('ADMIN') or @accountService.isAccountOwner(#request.accountId, authentication.name)")
    public ResponseEntity<PassbookResponseDTO> getPassbook(@Valid @RequestBody PassbookRequestDTO request,
                                                          Authentication authentication) {
        PassbookResponseDTO passbook = passbookService.getPassbook(request);
        return ResponseEntity.ok(passbook);
    }

    @GetMapping("/account/{accountNumber}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PassbookResponseDTO> getPassbookByAccountNumber(@PathVariable String accountNumber) {
        PassbookResponseDTO passbook = passbookService.getPassbookByAccountNumber(accountNumber);
        return ResponseEntity.ok(passbook);
    }

    @GetMapping("/my-passbook/{accountId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('CUSTOMER')")
    public ResponseEntity<PassbookResponseDTO> getMyPassbook(@PathVariable Long accountId,
                                                            Authentication authentication) {
        PassbookResponseDTO passbook = passbookService.getCustomerPassbook(accountId, authentication);
        return ResponseEntity.ok(passbook);
    }


    //  email passbook as PDF ke liye 
//    @PostMapping("/email")
//    @PreAuthorize("hasRole('ADMIN') or @accountService.isAccountOwner(#request.accountId, authentication.name)")
//    public ResponseEntity<String> emailPassbook(@Valid @RequestBody PassbookRequestDTO request,
//                                               Authentication authentication) {
//        try {
//            // Get passbook data
//            PassbookResponseDTO passbookData = passbookService.getPassbook(request);
//            
//            // Send email with PDF attachment
//            emailService.sendPassbookEmail(passbookData.getCustomerEmail(), 
//                                         passbookData.getCustomerName(), 
//                                         passbookData);
//            
//            return ResponseEntity.ok("Passbook has been sent to your registered email address: " + 
//                                   passbookData.getCustomerEmail());
//        } catch (Exception e) {
//            return ResponseEntity.internalServerError()
//                               .body("Failed to send passbook email: " + e.getMessage());
//        }
//    }
    
    @PostMapping("/email-my-passbook")
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<String> emailMyPassbook(
            Authentication authentication,
            @RequestBody(required = false) PassbookRequestOptionalDTO request) {

        try {
            if (request == null) {
                request = new PassbookRequestOptionalDTO();
            }

            PassbookResponseDTO passbookData =
                    passbookService.getPassbookForLoggedInCustomer(authentication.getName(), request);

            passbookData.setGeneratedAt(java.time.LocalDateTime.now());

            emailService.sendPassbookEmail(
                    passbookData.getCustomerEmail(),
                    passbookData.getCustomerName(),
                    passbookData
            );

            return ResponseEntity.ok("Passbook sent to your registered email: " + passbookData.getCustomerEmail());

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                                 .body("Failed to send passbook email: " + e.getMessage());
        }
    }




    
    @GetMapping("/email-my-passbook/{accountId}")
    @PreAuthorize("hasRole('CUSTOMER') and @accountService.isAccountOwner(#accountId, authentication.name)")
    public ResponseEntity<String> emailMyPassbook(@PathVariable Long accountId,
                                                  @RequestParam(required = false) String fromDate,
                                                  @RequestParam(required = false) String toDate,
                                                  Authentication authentication) {
        try {
            
            PassbookRequestDTO request = new PassbookRequestDTO();
            request.setAccountId(accountId);

            if (fromDate != null && !fromDate.isBlank()) {
                request.setFromDate(java.time.LocalDate.parse(fromDate));
            }
            if (toDate != null && !toDate.isBlank()) {
                request.setToDate(java.time.LocalDate.parse(toDate));
            }

          
            PassbookResponseDTO passbookData = passbookService.getPassbook(request);
            passbookData.setGeneratedAt(java.time.LocalDateTime.now()); // Ensure timestamp for PDF

            
            emailService.sendPassbookEmail(passbookData.getCustomerEmail(),
                                           passbookData.getCustomerName(),
                                           passbookData);

            return ResponseEntity.ok("Your passbook has been sent to: " + passbookData.getCustomerEmail());

        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                                 .body("Failed to send passbook email: " + e.getMessage());
        }
    }

    // Admin endpoint se  email passbook for any customer
//    @PostMapping("/admin/email/{accountId}")
//    @PreAuthorize("hasRole('ADMIN')")
//    public ResponseEntity<String> adminEmailPassbook(@PathVariable Long accountId,
//                                                    @RequestParam(required = false) String fromDate,
//                                                    @RequestParam(required = false) String toDate) {
//        try {
//            // Create request DTO
//            PassbookRequestDTO request = new PassbookRequestDTO();
//            request.setAccountId(accountId);
//            
//            // Parse dates if provided
//            if (fromDate != null && !fromDate.trim().isEmpty()) {
//                request.setFromDate(java.time.LocalDate.parse(fromDate));
//            }
//            if (toDate != null && !toDate.trim().isEmpty()) {
//                request.setToDate(java.time.LocalDate.parse(toDate));
//            }
//            
//            // Get passbook data
//            PassbookResponseDTO passbookData = passbookService.getPassbook(request);
//            
//            // Send email with PDF attachment
//            emailService.sendPassbookEmail(passbookData.getCustomerEmail(), 
//                                         passbookData.getCustomerName(), 
//                                         passbookData);
//            
//            return ResponseEntity.ok("Passbook sent to customer: " + passbookData.getCustomerEmail());
//        } catch (Exception e) {
//            return ResponseEntity.internalServerError()
//                               .body("Failed to send passbook email: " + e.getMessage());
//        }
//    }
}
