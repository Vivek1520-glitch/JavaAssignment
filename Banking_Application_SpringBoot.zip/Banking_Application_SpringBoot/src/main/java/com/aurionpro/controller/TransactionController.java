package com.aurionpro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.TransactionCreationResponseDTO;
import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.service.TransactionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	
	@PostMapping
	public ResponseEntity<TransactionCreationResponseDTO> createTransaction(
	        @Valid @RequestBody TransactionRequestDTO dto,
	        Authentication authentication) {

	    if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))
	            && !transactionService.canAccessAccount(dto.getAccountNumber(), authentication.getName())) {
	        throw new AccessDeniedException("You are not authorized to perform this operation");
	    }

	    // Make sure service returns TransactionCreationResponseDTO, not TransactionResponseDTO
	    TransactionCreationResponseDTO response = transactionService.createTransaction(dto);
	    return new ResponseEntity<>(response, HttpStatus.CREATED);
	}



	//@preauthorzed("cutomer(owner)/admin)
	@GetMapping("/account/{accountNumber}")
	public ResponseEntity<List<TransactionResponseDTO>> getTransactionsByAccountNumber(
			@PathVariable String accountNumber, Authentication authentication) {

		
		if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))
				&& !transactionService.canAccessAccount(accountNumber, authentication.getName())) {
			throw new AccessDeniedException("You are not authorized to view this account");
		}

		return ResponseEntity.ok(transactionService.getTransactionsByAccountNumber(accountNumber));
	}

	
	@GetMapping("/my-transactions")
	public ResponseEntity<List<TransactionResponseDTO>> getMyTransactions(Authentication authentication) {
		return ResponseEntity.ok(transactionService.getTransactionsByUsername(authentication.getName()));
	}

	
	
	@GetMapping("/account-transaction/{accountNumber}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<TransactionResponseDTO>> getAccountPassbook(@PathVariable String accountNumber,
			Authentication authentication) {

		if (!transactionService.canAccessAccount(accountNumber, authentication.getName())) {
			throw new AccessDeniedException("You are not authorized to view this account");
		}

		return ResponseEntity.ok(transactionService.getTransactionsByAccountNumber(accountNumber));
	}

	
	@GetMapping("/{transId}")
	public ResponseEntity<TransactionResponseDTO> getTransactionById(@PathVariable Long transId,
			Authentication authentication) {

		if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
			throw new AccessDeniedException("You are not authorized to view this transaction");
		}

		return ResponseEntity.ok(transactionService.getTransactionById(transId));
	}

	
	@GetMapping
	public ResponseEntity<List<TransactionResponseDTO>> getAllTransactions(Authentication authentication) {

		if (!authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
			throw new AccessDeniedException("You are not authorized to view all transactions");
		}

		return ResponseEntity.ok(transactionService.getAllTransactions());
	}
}
