package com.aurionpro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.service.AccountService;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@PostMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<AccountResponseDTO> createAccount(@RequestBody AccountRequestDTO dto) {
		return new ResponseEntity<>(accountService.createAccount(dto), HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and @accountService.isAccountOwner(#id, authentication.name))")
	public ResponseEntity<AccountResponseDTO> getAccount(@PathVariable Long id, Authentication authentication) {
		return ResponseEntity.ok(accountService.getAccountById(id));
	}

	@GetMapping("/customer/{customerId}")
	@PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and @customerService.isCustomerOwner(#customerId, authentication.name))")
	public ResponseEntity<List<AccountResponseDTO>> getAccountsByCustomer(@PathVariable Long customerId,
			Authentication authentication) {
		return ResponseEntity.ok(accountService.getAccountsByCustomer(customerId));
	}

	@GetMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<AccountResponseDTO>> getAllAccounts() {
		return ResponseEntity.ok(accountService.getAllAccounts());
	}

	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<String> deleteAccount(@PathVariable Long id) {
		accountService.deleteAccount(id);
		return ResponseEntity.ok("Account deleted successfully");
	}

	@GetMapping("/my-accounts")
	@PreAuthorize("hasRole('CUSTOMER')")
	public ResponseEntity<List<AccountResponseDTO>> getMyAccounts(Authentication authentication) {
		return ResponseEntity.ok(accountService.getAccountsByUsername(authentication.getName()));
	}
}