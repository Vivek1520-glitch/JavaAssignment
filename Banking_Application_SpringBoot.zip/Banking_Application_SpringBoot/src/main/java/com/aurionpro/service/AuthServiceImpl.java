package com.aurionpro.service;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aurionpro.dto.LoginDto;
import com.aurionpro.dto.RegistrationDto;
import com.aurionpro.dto.UserResponseDto;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.exception.DuplicateResourceException;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.repo.CustomerRepository;
import com.aurionpro.repo.RoleRepository;
import com.aurionpro.repo.UserRepository;
import com.aurionpro.security.JwtTokenProvider;

import jakarta.annotation.PostConstruct;

@Service
public class AuthServiceImpl implements AuthService {

	private static final Logger logger = LoggerFactory.getLogger(AuthServiceImpl.class);

	private final UserRepository userRepository;
	private final RoleRepository roleRepository;
	private final CustomerRepository customerRepository;
	private final PasswordEncoder passwordEncoder;
	private final AuthenticationManager authenticationManager;
	private final JwtTokenProvider jwtTokenProvider;
	private final EmailService emailService;

	public AuthServiceImpl(UserRepository userRepository, RoleRepository roleRepository,
			CustomerRepository customerRepository, PasswordEncoder passwordEncoder,
			AuthenticationManager authenticationManager, JwtTokenProvider jwtTokenProvider, EmailService emailService) {
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		this.customerRepository = customerRepository;
		this.passwordEncoder = passwordEncoder;
		this.authenticationManager = authenticationManager;
		this.jwtTokenProvider = jwtTokenProvider;
		this.emailService = emailService;
	}

	@Override
	@Transactional
	public UserResponseDto register(RegistrationDto registerDto) {
		logger.info("Starting registration process for username: {}", registerDto.getUsername());

		if (userRepository.existsByUsername(registerDto.getUsername())) {
			logger.warn("Registration failed - Username already exists: {}", registerDto.getUsername());
			throw new DuplicateResourceException("Username is already taken");
		}

		Role role = roleRepository.findByNameIgnoreCase(registerDto.getRole()).orElseThrow(() -> {
			logger.error("Registration failed - Role not found: {}", registerDto.getRole());
			return new ResourceNotFoundException("Role does not exist");
		});

		User user = new User();
		user.setUsername(registerDto.getUsername());
		user.setPassword(passwordEncoder.encode(registerDto.getPassword()));
		user.setRoles(Collections.singleton(role));

		String roleName = role.getName();
		boolean isAdminRole = "ADMIN".equalsIgnoreCase(roleName) || "ROLE_ADMIN".equalsIgnoreCase(roleName);
		boolean isCustomerRole = "CUSTOMER".equalsIgnoreCase(roleName) || "ROLE_CUSTOMER".equalsIgnoreCase(roleName);

		user.setStatus(isAdminRole ? "ACTIVE" : "INACTIVE");

		User savedUser = userRepository.save(user);
		logger.info("User successfully created with ID: {}, role: {}, status: {}", savedUser.getUserId(), roleName,
				savedUser.getStatus());

		Customer savedCustomer = null;
		if (isCustomerRole) {
			Customer customer = new Customer(savedUser);
			savedCustomer = customerRepository.save(customer);
			logger.info("Customer entity created for user ID: {}", savedUser.getUserId());

			if (isValidEmail(registerDto.getEmailId())) {
				sendWelcomeEmailAsync(registerDto.getEmailId(), registerDto.getUsername());
			} else {
				logger.warn("Invalid email provided for customer: {}", registerDto.getEmailId());
			}
		} else {
			logger.info("No customer entity created for ADMIN user: {}", savedUser.getUsername());
		}

		UserResponseDto response = new UserResponseDto();
		response.setUserId(savedUser.getUserId());
		response.setUsername(savedUser.getUsername());
		response.setEmailId(registerDto.getEmailId());
		response.setContactNo(registerDto.getContactNo());
		response.setRole(role.getName());
		response.setStatus(savedUser.getStatus());

		logger.info("Registration completed successfully for user: {} with role: {}", savedUser.getUsername(),
				role.getName());
		return response;
	}

	@Override
	public String login(LoginDto loginDto) {
		logger.info("Login attempt for username: {}", loginDto.getUsername());

		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));

			String token = jwtTokenProvider.generateToken(authentication);
			logger.info("Login successful for username: {}", loginDto.getUsername());
			return token;

		} catch (Exception e) {
			logger.warn("Login failed for username: {} - {}", loginDto.getUsername(), e.getMessage());
			throw e;
		}
	}

	@Transactional
	public void syncUserStatusWithCustomer() {
		logger.info("Starting user status synchronization with customer status");

		List<Customer> allCustomers = customerRepository.findAll();
		int updatedCount = 0;

		for (Customer customer : allCustomers) {
			User user = customer.getUser();
			if (user == null) {
				logger.warn("Customer ID {} has no associated user", customer.getCustomerId());
				continue;
			}

			String oldStatus = user.getStatus();
			String newStatus = switch (customer.getStatus()) {
			case PENDING -> "INACTIVE";
			case APPROVED -> "ACTIVE";
			case REJECTED -> "INACTIVE";
			};

			if (!oldStatus.equals(newStatus)) {
				user.setStatus(newStatus);
				userRepository.save(user);
				updatedCount++;

				logger.info("User {} status updated: {} → {}", user.getUsername(), oldStatus, newStatus);

				if ("ACTIVE".equals(newStatus) && customer.getUser() != null) {
					sendAccountApprovalEmailAsync(customer);
				}
			}
		}

		logger.info("User status synchronization completed. {} users updated.", updatedCount);
	}

	@PostConstruct
	public void initSync() {
		logger.info("Initializing user-customer status synchronization");
		syncUserStatusWithCustomer();
	}

	private boolean isValidEmail(String email) {
		if (email == null || email.trim().isEmpty()) {
			return false;
		}

		String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
		boolean isValid = email.matches(emailRegex);
		logger.debug("Email validation for {}: {}", email, isValid);
		return isValid;
	}

	private void sendWelcomeEmailAsync(String email, String username) {
		try {
			String customerName = extractCustomerName(username);
			logger.info("Attempting to send welcome email to: {} for customer: {}", email, customerName);
			emailService.sendWelcomeEmail(email.trim(), customerName);
			logger.info("Welcome email sent successfully to: {}", email);
		} catch (Exception e) {
			logger.error("Failed to send welcome email to: {} - {}", email, e.getMessage(), e);
			// Don't throw exception to avoid blocking registration
		}
	}

	private void sendAccountApprovalEmailAsync(Customer customer) {
		try {

			if (customer.getUser() != null) {
				String customerName = extractCustomerName(customer.getUser().getUsername());
				// emailService.sendAccountCreatedEmail(customerEmail, customerName,
				// accountNumber);
				logger.info("Account approval email would be sent for customer: {}", customer.getCustomerId());
			}
		} catch (Exception e) {
			logger.error("Failed to send account approval email for customer: {} - {}", customer.getCustomerId(),
					e.getMessage());
		}
	}

	private String extractCustomerName(String username) {
		if (username == null || username.trim().isEmpty()) {
			return "Valued Customer";
		}

		String cleanName = username.replaceAll("[^a-zA-Z]", " ").trim();

		if (cleanName.isEmpty()) {
			return capitalizeFirstLetter(username);
		}

		String[] words = cleanName.split("\\s+");
		StringBuilder result = new StringBuilder();

		for (String word : words) {
			if (!word.isEmpty()) {
				if (result.length() > 0) {
					result.append(" ");
				}
				result.append(capitalizeFirstLetter(word));
			}
		}

		return result.toString().isEmpty() ? "Valued Customer" : result.toString();
	}

	private String capitalizeFirstLetter(String str) {
		if (str == null || str.isEmpty()) {
			return "Valued Customer";
		}

		str = str.trim();
		if (str.isEmpty()) {
			return "Valued Customer";
		}

		return str.substring(0, 1).toUpperCase() + (str.length() > 1 ? str.substring(1).toLowerCase() : "");
	}

	@Transactional
	public void notifyCustomerDeletion(String email, String customerName) {
		if (isValidEmail(email)) {
			try {
				emailService.sendCustomerDeletedNotification(email, customerName);
				logger.info("Customer deletion notification sent to: {}", email);
			} catch (Exception e) {
				logger.error("Failed to send customer deletion notification to: {} - {}", email, e.getMessage());
			}
		}
	}

	public void sendPasswordResetEmail(String email, String resetToken) {
		if (isValidEmail(email)) {
			try {
				emailService.sendPasswordResetEmail(email, resetToken);
				logger.info("Password reset email sent to: {}", email);
			} catch (Exception e) {
				logger.error("Failed to send password reset email to: {} - {}", email, e.getMessage());
				throw e;
			}
		} else {
			throw new IllegalArgumentException("Invalid email address provided");
		}
	}
}