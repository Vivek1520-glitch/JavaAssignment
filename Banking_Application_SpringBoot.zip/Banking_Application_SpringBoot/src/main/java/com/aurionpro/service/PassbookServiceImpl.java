package com.aurionpro.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.PassbookRequestDTO;
import com.aurionpro.dto.PassbookRequestOptionalDTO;
import com.aurionpro.dto.PassbookResponseDTO;
import com.aurionpro.dto.PassbookTransactionResponseDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Transaction;
import com.aurionpro.entity.User;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.exception.UnauthorizedAccessException;
import com.aurionpro.repo.AccountRepository;
import com.aurionpro.repo.TransactionRepository;
import com.aurionpro.repo.UserRepository;

@Service
public class PassbookServiceImpl implements PassbookService {

	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private TransactionRepository transactionRepository;
	@Autowired
	private UserRepository userRepository;

	@Override
	public PassbookResponseDTO getPassbook(PassbookRequestDTO request) {
		Account account = accountRepository.findById(request.getAccountId()).orElseThrow(
				() -> new ResourceNotFoundException("Account not found with ID: " + request.getAccountId()));

		checkAccountAccess(account);

		LocalDateTime fromDate = request.getFromDate() != null ? request.getFromDate().atStartOfDay()
				: LocalDateTime.MIN;
		LocalDateTime toDate = request.getToDate() != null ? request.getToDate().atTime(LocalTime.MAX)
				: LocalDateTime.now();

		List<Transaction> transactions = transactionRepository
				.findByAccount_AccountIdAndDateBetweenOrderByDateDesc(account.getAccountId(), fromDate, toDate);

		return buildPassbookResponse(account, transactions);
	}

	@Override
	public PassbookResponseDTO getPassbookByAccountNumber(String accountNumber) {
		Account account = accountRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with number: " + accountNumber));

		checkAccountAccess(account);

		List<Transaction> transactions = transactionRepository
				.findByAccount_AccountIdOrderByDateDesc(account.getAccountId());

		return buildPassbookResponse(account, transactions);
	}

	@Override
	public PassbookResponseDTO getCustomerPassbook(Long accountId, Authentication authentication) {
	  
	    Account account = accountRepository.findById(accountId)
	            .orElseThrow(() -> new ResourceNotFoundException("Account not found with ID: " + accountId));

	  
	    boolean isAdmin = authentication.getAuthorities().stream()
	            .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

	    if (!isAdmin) {
	       
	        if (!account.getCustomer().getUser().getUsername().equals(authentication.getName())) {
	            throw  new UnauthorizedAccessException("You can only access your own account passbook");
	        }
	    }

	 
	    List<Transaction> transactions = transactionRepository.findByAccount_AccountIdOrderByDateDesc(accountId);

	    return buildPassbookResponse(account, transactions);
	}


	private PassbookResponseDTO buildPassbookResponse(Account account, List<Transaction> transactions) {
		List<PassbookTransactionResponseDTO> transactionDTOs = transactions.stream().map(tx -> {
			PassbookTransactionResponseDTO dto = new PassbookTransactionResponseDTO();
			dto.setTransId(tx.getTransId());
			dto.setTranType(tx.getTranType());
			dto.setAmount(tx.getAmount());
			dto.setDate(tx.getDate());
			dto.setBalanceAfterTransaction(tx.getAccount().getBalance());
			dto.setDescription(generateTransactionDescription(tx));
			return dto;
		}).collect(Collectors.toList());

		PassbookResponseDTO passbook = new PassbookResponseDTO();
		passbook.setAccountId(account.getAccountId());
		passbook.setAccountNumber(account.getAccountNumber());
		passbook.setAccountType(account.getAccountType());
		passbook.setCurrentBalance(account.getBalance());
		passbook.setCustomerEmail(account.getCustomer().getEmailId());
		passbook.setCustomerName(account.getCustomer().getUser().getUsername());
		passbook.setTransactions(transactionDTOs);

		return passbook;
	}

	@Override
	public PassbookResponseDTO getPassbookForLoggedInCustomer(String username, PassbookRequestOptionalDTO request) {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new UnauthorizedAccessException("User not found: " + username));

		if (user.getCustomer() == null || user.getCustomer().getAccounts().isEmpty()) {
			throw new ResourceNotFoundException("No account found for user: " + username);
		}

		Account account = user.getCustomer().getAccounts().get(0);

	
		if (!canAccessAccount(account, username)) {
			throw new UnauthorizedAccessException("You cannot access this account's passbook");
		}

	
		LocalDateTime fromDate = request.getFromDate() != null ? request.getFromDate().atStartOfDay()
				: LocalDateTime.MIN;
		LocalDateTime toDate = request.getToDate() != null ? request.getToDate().atTime(LocalTime.MAX)
				: LocalDateTime.now();

	
		List<Transaction> transactions = transactionRepository
				.findByAccount_AccountIdAndDateBetweenOrderByDateDesc(account.getAccountId(), fromDate, toDate);

	
		return buildPassbookResponse(account, transactions);
	}

	private void checkAccountAccess(Account account) {
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();

	  
	    boolean isAdmin = auth.getAuthorities().stream()
	            .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_ADMIN"));

	    if (!isAdmin) {
	      
	        String username = auth.getName();
	        if (!account.getCustomer().getUser().getUsername().equals(username)) {
	            throw new UnauthorizedAccessException("You can only access your own account passbook");
	        }
	    }
	}


	private String generateTransactionDescription(Transaction transaction) {
		String type = transaction.getTranType().toLowerCase();
		switch (type) {
		case "credit":
			return "Amount credited to account";
		case "debit":
			return "Amount debited from account";
		case "transfer":
			return "Fund transfer";
		default:
			return "Transaction";
		}
	}

	private void canAccessAccount(Account account) {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		if (!canAccessAccount(account, username)) {
			throw new UnauthorizedAccessException("You can only access your own account passbook");
		}
	}

	public boolean canAccessAccount(Account account, String username) {
		User currentUser = userRepository.findByUsername(username)
				.orElseThrow(() -> new UnauthorizedAccessException("User not found"));

		boolean isAdmin = currentUser.getRoles().stream().anyMatch(role -> role.getName().equalsIgnoreCase("ADMIN"));

		if (isAdmin)
			return true;

		if (currentUser.getCustomer() != null
				&& currentUser.getCustomer().getCustomerId().equals(account.getCustomer().getCustomerId())) {
			return true;
		}

		return false;
	}
}
