package com.aurionpro.service;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aurionpro.dto.AddressDTO;
import com.aurionpro.dto.CustomerProfileCompletionDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;
import com.aurionpro.dto.PendingCustomerResponseDTO;
import com.aurionpro.entity.Address;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Customer.CustomerStatus;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.exception.InvalidRequestException;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.repo.AddressRepository;
import com.aurionpro.repo.CustomerRepository;
import com.aurionpro.repo.RoleRepository;
import com.aurionpro.repo.UserRepository;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private EmailService emailService;

	// customer creation sathi cha block
	@Override
	public CustomerResponseDTO createCustomer(CustomerRequestDTO dto) {
		if (customerRepository.existsByEmailId(dto.getEmailId())) {
			throw new InvalidRequestException("Email already exists: " + dto.getEmailId());
		}
		if (userRepository.findByUsername(dto.getUsername()).isPresent()) {
			throw new InvalidRequestException("Username already exists: " + dto.getUsername());
		}

		User user = new User();
		user.setUsername(dto.getUsername());
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setStatus("ACTIVE");

		Role customerRole = roleRepository.findByNameIgnoreCase("ROLE_CUSTOMER")
				.orElseThrow(() -> new ResourceNotFoundException("Role CUSTOMER not found"));
		Set<Role> roles = new HashSet<>();
		roles.add(customerRole);
		user.setRoles(roles);

		Customer customer = new Customer();
		customer.setEmailId(dto.getEmailId());
		customer.setContactNo(dto.getContactNo());
		customer.setDob(dto.getDob());
		customer.setStatus(CustomerStatus.APPROVED);

		if (dto.getAddress() != null) {
			Address address = new Address();
			address.setCity(dto.getAddress().getCity());
			address.setState(dto.getAddress().getState());
			address.setPincode(dto.getAddress().getPincode());
			customer.setAddress(address);
		}

		customer.setUser(user);
		user.setCustomer(customer);

		Customer savedCustomer = customerRepository.save(customer);
		emailService.sendWelcomeEmail(customer.getEmailId(), user.getUsername());
		return mapToResponseDTO(savedCustomer);
	}

	// customer profile complete sathi cha
	@Transactional
	public CustomerResponseDTO completeCustomerProfile(CustomerProfileCompletionDTO dto) {
		User user = userRepository.findById(dto.getUserId())
				.orElseThrow(() -> new ResourceNotFoundException("User not found"));
		user.setStatus("ACTIVE");

		Customer customer = customerRepository.findByUser(user)
				.orElseThrow(() -> new ResourceNotFoundException("Customer profile not found for user"));

		if (customer.getStatus() != CustomerStatus.PENDING) {
			throw new InvalidRequestException("Customer profile is not in PENDING status");
		}

		if (!Objects.equals(customer.getEmailId(), dto.getEmailId())
				&& customerRepository.existsByEmailId(dto.getEmailId())) {
			throw new InvalidRequestException("Email already exists: " + dto.getEmailId());
		}

		customer.setEmailId(dto.getEmailId());
		customer.setContactNo(dto.getContactNo());
		customer.setDob(dto.getDob());
		customer.setStatus(dto.getStatus());

		Address address = new Address();
		address.setCity(dto.getCity());
		address.setState(dto.getState());
		address.setPincode(dto.getPincode());
		addressRepository.save(address);
		customer.setAddress(address);

		Customer savedCustomer = customerRepository.save(customer);
		emailService.sendAccountCreatedEmail(customer.getEmailId(), user.getUsername(),
				"Account-" + customer.getCustomerId());

		return mapToResponseDTO(savedCustomer);
	}

	public boolean isCustomerOwner(Long customerId, String username) {
		return customerRepository.findById(customerId)
				.map(customer -> customer.getUser().getUsername().equals(username)).orElse(false);
	}

	public CustomerResponseDTO getCustomerByUsername(String username) {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new ResourceNotFoundException("User not found"));
		Customer customer = customerRepository.findByUser(user)
				.orElseThrow(() -> new ResourceNotFoundException("Customer profile not found"));
		return mapToResponseDTO(customer);
	}

	@Transactional
	public CustomerResponseDTO updateCustomerByUsername(String username, CustomerUpdateDTO dto) {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new ResourceNotFoundException("User not found"));
		Customer customer = customerRepository.findByUser(user)
				.orElseThrow(() -> new ResourceNotFoundException("Customer profile not found"));

		if (dto.getUsername() != null && !dto.getUsername().isBlank()
				&& !dto.getUsername().equals(user.getUsername())) {
			if (userRepository.findByUsername(dto.getUsername()).isPresent()) {
				throw new InvalidRequestException("Username already exists: " + dto.getUsername());
			}
			user.setUsername(dto.getUsername());
		}
		if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
			user.setPassword(passwordEncoder.encode(dto.getPassword()));
		}
		userRepository.save(user);

		if (dto.getEmailId() != null && !dto.getEmailId().isBlank()) {
			if (!dto.getEmailId().equals(customer.getEmailId())
					&& customerRepository.existsByEmailId(dto.getEmailId())) {
				throw new InvalidRequestException("Email already exists: " + dto.getEmailId());
			}
			customer.setEmailId(dto.getEmailId());
		}
		if (dto.getContactNo() != null && !dto.getContactNo().isBlank()) {
			customer.setContactNo(dto.getContactNo());
		}
		if (dto.getDob() != null) {
			customer.setDob(dto.getDob());
		}

		if (dto.getAddress() != null) {
			Address address = customer.getAddress();
			if (address == null)
				address = new Address();
			if (dto.getAddress().getCity() != null)
				address.setCity(dto.getAddress().getCity());
			if (dto.getAddress().getState() != null)
				address.setState(dto.getAddress().getState());
			if (dto.getAddress().getPincode() != null)
				address.setPincode(dto.getAddress().getPincode());
			customer.setAddress(address);
		}

		Customer updatedCustomer = customerRepository.save(customer);
		emailService.sendAccountUpdatedEmail(customer.getEmailId(), user.getUsername());

		return mapToResponseDTO(updatedCustomer);
	}

	@Override
	@Transactional
	public CustomerResponseDTO updateCustomer(Long id, CustomerUpdateDTO dto) {
		Customer customer = customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
		User user = customer.getUser();

		if (dto.getUsername() != null && !dto.getUsername().isBlank()
				&& !dto.getUsername().equals(user.getUsername())) {
			if (userRepository.findByUsername(dto.getUsername()).isPresent()) {
				throw new InvalidRequestException("Username already exists: " + dto.getUsername());
			}
			user.setUsername(dto.getUsername());
		}
		if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
			user.setPassword(passwordEncoder.encode(dto.getPassword()));
		}
		userRepository.save(user);

		if (dto.getEmailId() != null && !dto.getEmailId().isBlank()) {
			if (!dto.getEmailId().equals(customer.getEmailId())
					&& customerRepository.existsByEmailId(dto.getEmailId())) {
				throw new InvalidRequestException("Email already exists: " + dto.getEmailId());
			}
			customer.setEmailId(dto.getEmailId());
		}
		if (dto.getContactNo() != null && !dto.getContactNo().isBlank()) {
			customer.setContactNo(dto.getContactNo());
		}
		if (dto.getDob() != null) {
			customer.setDob(dto.getDob());
		}

		if (dto.getAddress() != null) {
			Address address = customer.getAddress();
			if (address == null)
				address = new Address();
			if (dto.getAddress().getCity() != null)
				address.setCity(dto.getAddress().getCity());
			if (dto.getAddress().getState() != null)
				address.setState(dto.getAddress().getState());
			if (dto.getAddress().getPincode() != null)
				address.setPincode(dto.getAddress().getPincode());
			customer.setAddress(address);
		}

		Customer updatedCustomer = customerRepository.save(customer);
		emailService.sendAccountUpdatedEmail(customer.getEmailId(), user.getUsername());

		return mapToResponseDTO(updatedCustomer);
	}

	@Override
	public CustomerResponseDTO getCustomerById(Long id) {
		return customerRepository.findById(id).map(this::mapToResponseDTO)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
	}

	@Override
	public List<CustomerResponseDTO> getAllCustomers() {
		return customerRepository.findAll().stream().map(this::mapToResponseDTO).collect(Collectors.toList());
	}

	@Override
	public void deleteCustomer(Long id) {
		Customer customer = customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
		emailService.sendCustomerDeletedNotification(customer.getEmailId(), customer.getUser().getUsername());
		customerRepository.delete(customer);
	}

	public List<PendingCustomerResponseDTO> getPendingCustomers() {
		return customerRepository.findByStatus(Customer.CustomerStatus.PENDING).stream()
				.map(customer -> new PendingCustomerResponseDTO(customer.getCustomerId(),
						customer.getUser() != null ? customer.getUser().getUserId() : null,
						customer.getUser() != null ? customer.getUser().getUsername() : null, customer.getStatus()))
				.collect(Collectors.toList());
	}

	private CustomerResponseDTO mapToResponseDTO(Customer customer) {
		CustomerResponseDTO dto = new CustomerResponseDTO();
		dto.setCustomerId(customer.getCustomerId());
		dto.setEmailId(customer.getEmailId());
		dto.setContactNo(customer.getContactNo());
		dto.setDob(customer.getDob());
		dto.setStatus(customer.getStatus());

		if (customer.getAddress() != null) {
			AddressDTO addressDTO = new AddressDTO();
			addressDTO.setCity(customer.getAddress().getCity());
			addressDTO.setState(customer.getAddress().getState());
			addressDTO.setPincode(customer.getAddress().getPincode());
			dto.setAddress(addressDTO);
		}

		if (customer.getUser() != null) {
			dto.setUserId(customer.getUser().getUserId());
			dto.setUsername(customer.getUser().getUsername());
		}

		return dto;
	}
}
