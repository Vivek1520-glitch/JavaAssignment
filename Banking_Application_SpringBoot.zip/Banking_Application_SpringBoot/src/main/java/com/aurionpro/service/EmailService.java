package com.aurionpro.service;

import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.TransactionCreationResponseDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.dto.PassbookResponseDTO;

public interface EmailService {
    void sendWelcomeEmail(String toEmail, String customerName);
    
    void sendAccountCreatedEmail(String toEmail, String customerName, String accountNumber);
    
    void sendTransactionNotification(String toEmail, TransactionCreationResponseDTO transaction, String customerName);
    
    void sendPasswordResetEmail(String toEmail, String resetToken);
    
    void sendCustomerDeletedNotification(String toEmail, String customerName);
    
    void sendPassbookEmail(String toEmail, String customerName, PassbookResponseDTO passbookData);
    
    void sendAccountUpdatedEmail(String toEmail, String customerName);
}