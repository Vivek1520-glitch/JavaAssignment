package com.aurionpro.service;

import com.aurionpro.dto.AddressDTO;

public interface AddressService {
	AddressDTO createAddress(AddressDTO addressDTO);

	AddressDTO updateAddress(Long id, AddressDTO addressDTO);

	AddressDTO getAddressById(Long id);

	void deleteAddress(Long id);
}
