package com.aurionpro.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aurionpro.dto.TransactionCreationResponseDTO;
import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Transaction;
import com.aurionpro.entity.User;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.repo.AccountRepository;
import com.aurionpro.repo.CustomerRepository;
import com.aurionpro.repo.TransactionRepository;
import com.aurionpro.repo.UserRepository;

import jakarta.validation.ValidationException;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailService emailService;

	private static final double SAVINGS_MIN_BALANCE = 1000.0;
	private static final double DAILY_TRANSFER_LIMIT = 100000.0;
	private static final double DAILY_WITHDRAWAL_LIMIT_SAVINGS = 50000.0;

	
	@Override
	@Transactional
	public TransactionCreationResponseDTO createTransaction(TransactionRequestDTO dto) {

	    if (dto.getAmount() == null || dto.getAmount() <= 0) {
	        throw new ValidationException("Transaction amount must be greater than 0");
	    }

	    if (dto.getAmount() % 100 != 0 && dto.getAmount() % 500 != 0) {
	        throw new ValidationException("Transaction amount must be multiple of 100 or 500");
	    }

	    Account account = accountRepository.findByAccountNumber(dto.getAccountNumber())
	            .orElseThrow(() -> new ResourceNotFoundException("Source Account not found"));

	    Customer customer = account.getCustomer();
	    Account targetAccount = null;

	    if ("transfer".equalsIgnoreCase(dto.getTranType())) {

	        if (dto.getTargetAccountNumber() == null || dto.getTargetAccountNumber().isBlank()) {
	            throw new ValidationException("Target account number required for transfer");
	        }

	        targetAccount = accountRepository.findByAccountNumber(dto.getTargetAccountNumber())
	                .orElseThrow(() -> new ResourceNotFoundException("Target Account not found"));

	        if (account.getAccountNumber().equals(targetAccount.getAccountNumber())) {
	            throw new ValidationException("Cannot transfer to the same account");
	        }

	        double totalTransferredToday = transactionRepository.sumTransactionsToday(
	                account.getAccountId(),
	                LocalDateTime.now().toLocalDate().atStartOfDay(),
	                LocalDateTime.now().toLocalDate().atTime(23, 59, 59)
	        );

	        if (totalTransferredToday + dto.getAmount() > DAILY_TRANSFER_LIMIT) {
	            throw new ValidationException("Daily transfer limit exceeded");
	        }
	    }

	    Transaction transaction = new Transaction();
	    transaction.setTranType(dto.getTranType());
	    transaction.setAmount(dto.getAmount());
	    transaction.setDate(LocalDateTime.now());
	    transaction.setAccount(account);
	    transaction.setCustomer(customer);

	    switch (dto.getTranType().toLowerCase()) {
	        case "debit":
	            validateDebit(account, dto.getAmount());
	            account.setBalance(account.getBalance() - dto.getAmount());
	            transaction.setDescription("Debited ₹" + dto.getAmount());
	            break;

	        case "credit":
	            account.setBalance(account.getBalance() + dto.getAmount());
	            transaction.setDescription("Credited ₹" + dto.getAmount());
	            break;

	        case "transfer":
	            validateDebit(account, dto.getAmount());
	            account.setBalance(account.getBalance() - dto.getAmount());
	            targetAccount.setBalance(targetAccount.getBalance() + dto.getAmount());
	            accountRepository.save(targetAccount);

	            transaction.setDescription(
	                    "Transferred ₹" + dto.getAmount() + " to account " + targetAccount.getAccountNumber());
	            transaction.setToAccountNumber(targetAccount.getAccountNumber());

	            Transaction targetTx = new Transaction();
	            targetTx.setTranType("credit");
	            targetTx.setAmount(dto.getAmount());
	            targetTx.setDate(LocalDateTime.now());
	            targetTx.setAccount(targetAccount);
	            targetTx.setCustomer(targetAccount.getCustomer());
	            targetTx.setToAccountNumber(account.getAccountNumber());
	            targetTx.setDescription("Received ₹" + dto.getAmount() + " from account " + account.getAccountNumber());
	            transactionRepository.save(targetTx);

	            emailService.sendTransactionNotification(targetAccount.getCustomer().getEmailId(),
	                    mapToCreationDTO(targetTx),
	                    targetAccount.getCustomer().getUser().getUsername());
	            break;

	        default:
	            throw new ValidationException("Invalid transaction type");
	    }

	    accountRepository.save(account);
	    Transaction saved = transactionRepository.save(transaction);

	    TransactionCreationResponseDTO responseDTO = mapToCreationDTO(saved);
	    emailService.sendTransactionNotification(customer.getEmailId(), responseDTO, customer.getUser().getUsername());

	    return responseDTO;
	}


	private void validateDebit(Account account, double amount) {
		if (amount > account.getBalance()) {
			throw new ValidationException("Insufficient balance. Cannot go negative");
		}

		if ("savings".equalsIgnoreCase(account.getAccountType())) {
			if (account.getBalance() - amount < SAVINGS_MIN_BALANCE) {
				throw new ValidationException("Cannot debit. Minimum savings balance must be ₹" + SAVINGS_MIN_BALANCE);
			}
			if (amount > DAILY_WITHDRAWAL_LIMIT_SAVINGS) {
				throw new ValidationException("Daily withdrawal limit exceeded for savings account");
			}
		}

		if ("current".equalsIgnoreCase(account.getAccountType())) {
			if (account.getBalance() - amount < 0) {
				throw new ValidationException("Insufficient balance. Current account cannot go negative");
			}
		}
	}

	@Override
	public boolean canAccessAccount(String accountNumber, String username) {
		if (accountNumber == null || username == null)
			return false;
		return accountRepository.findByAccountNumber(accountNumber)
				.map(account -> account.getCustomer().getUser().getUsername().equals(username)).orElse(false);
	}

	@Override
	public List<TransactionResponseDTO> getTransactionsByAccountNumber(String accountNumber) {
		Account account = accountRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found"));

		return transactionRepository.findByAccountAccountId(account.getAccountId()).stream().map(this::mapToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<TransactionResponseDTO> getTransactionsByCustomer(Long customerId) {
		return transactionRepository.findByCustomerCustomerId(customerId).stream().map(this::mapToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public TransactionResponseDTO getTransactionById(Long transId) {
		Transaction tx = transactionRepository.findById(transId)
				.orElseThrow(() -> new ResourceNotFoundException("Transaction not found"));
		return mapToDTO(tx);
	}

	@Override
	public List<TransactionResponseDTO> getTransactionsByUsername(String username) {
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new ResourceNotFoundException("User not found"));

		Customer customer = customerRepository.findByUser(user)
				.orElseThrow(() -> new ResourceNotFoundException("Customer profile not found"));

		return transactionRepository.findByCustomerCustomerId(customer.getCustomerId()).stream().map(this::mapToDTO)
				.collect(Collectors.toList());
	}

	@Override
	public List<TransactionResponseDTO> getAllTransactions() {
		return transactionRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
	}

	private TransactionResponseDTO mapToDTO(Transaction tx) {
		TransactionResponseDTO dto = new TransactionResponseDTO();
		dto.setTransId(tx.getTransId());
		dto.setTranType(tx.getTranType());
		dto.setAmount(tx.getAmount());
		dto.setDate(tx.getDate());
		dto.setAccountNumber(tx.getAccount().getAccountNumber());
		dto.setCustomerName(tx.getCustomer().getUser().getUsername());
		dto.setBalanceAfterTransaction(tx.getAccount().getBalance());
		dto.setDescription(tx.getDescription());
		dto.setToAccountNumber(tx.getToAccountNumber());
		return dto;
	}
	
	private TransactionCreationResponseDTO mapToCreationDTO(Transaction tx) {
	    TransactionCreationResponseDTO dto = new TransactionCreationResponseDTO();
	    dto.setTransId(tx.getTransId());
	    dto.setTranType(tx.getTranType());
	    dto.setAmount(tx.getAmount());
	    dto.setDate(tx.getDate());
	    dto.setAccountNumber(tx.getAccount().getAccountNumber());
	    dto.setCustomerName(tx.getCustomer().getUser().getUsername());
	    dto.setBalanceAfterTransaction(tx.getAccount().getBalance());
	    dto.setDescription(tx.getDescription());
	    dto.setToAccountNumber(tx.getToAccountNumber());
	    return dto;
	}



}

