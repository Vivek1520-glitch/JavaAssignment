package com.aurionpro.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.PassbookResponseDTO;
import com.aurionpro.dto.PassbookTransactionResponseDTO;
import com.aurionpro.exception.EmailSendingException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class PdfService {

	private static final float MARGIN = 50;
	private static final float FONT_SIZE_TITLE = 16;
	private static final float FONT_SIZE_HEADER = 12;
	private static final float FONT_SIZE_NORMAL = 10;
	private static final float LINE_HEIGHT = 15;

	public byte[] generatePassbookPdf(PassbookResponseDTO passbookData) {
		PDDocument document = null;
		PDPageContentStream contentStream = null;

		try {
			// Validate input data
			if (passbookData == null) {
				throw new IllegalArgumentException("Passbook data cannot be null");
			}

			document = new PDDocument();
			PDPage page = new PDPage();
			document.addPage(page);

			contentStream = new PDPageContentStream(document, page);

			float yPosition = page.getMediaBox().getHeight() - MARGIN;

			// Add content step by step with error handling
			yPosition = addBankHeader(contentStream, yPosition);
			yPosition = addAccountDetails(contentStream, yPosition, passbookData);
			yPosition = addTransactionSection(contentStream, yPosition, passbookData);

			contentStream.close();
			contentStream = null; // Set to null after closing

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			document.save(outputStream);
			document.close();
			document = null; // Set to null after closing

			return outputStream.toByteArray();

		} catch (Exception e) {
			// Clean up resources
			if (contentStream != null) {
				try {
					contentStream.close();
				} catch (IOException ignored) {
				}
			}
			if (document != null) {
				try {
					document.close();
				} catch (IOException ignored) {
				}
			}

			throw new EmailSendingException("Error generating PDF: " + e.getMessage());
		}
	}

	private float addBankHeader(PDPageContentStream contentStream, float yPosition) throws IOException {
		// Bank name
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_TITLE);
		contentStream.newLineAtOffset(MARGIN + 120, yPosition);
		contentStream.showText("V_Banking");
		contentStream.endText();

		yPosition -= 25;

		// Subtitle
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_HEADER);
		contentStream.newLineAtOffset(MARGIN + 160, yPosition);
		contentStream.showText("Account Statement");
		contentStream.endText();

		yPosition -= 30;

		// Draw separator line
		contentStream.setLineWidth(1);
		contentStream.moveTo(MARGIN, yPosition);
		contentStream.lineTo(550, yPosition);
		contentStream.stroke();

		return yPosition - 20;
	}

	private float addAccountDetails(PDPageContentStream contentStream, float yPosition,
			PassbookResponseDTO passbookData) throws IOException {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

		// Prepare account details with null checks
		String customerName = passbookData.getCustomerName() != null ? passbookData.getCustomerName() : "N/A";
		String accountNumber = passbookData.getAccountNumber() != null ? passbookData.getAccountNumber() : "N/A";
		String accountType = passbookData.getAccountType() != null ? passbookData.getAccountType().toUpperCase()
				: "N/A";
		String email = passbookData.getCustomerEmail() != null ? passbookData.getCustomerEmail() : "N/A";
		String balance = String.format("Rs %.2f",
				passbookData.getCurrentBalance() != null ? passbookData.getCurrentBalance() : 0.0);
		String statementDate = passbookData.getGeneratedAt() != null ? passbookData.getGeneratedAt().format(formatter)
				: java.time.LocalDateTime.now().format(formatter);

		String[][] details = { { "Account Holder:", customerName }, { "Account Number:", accountNumber },
				{ "Account Type:", accountType }, { "Email:", email }, { "Current Balance:", balance },
				{ "Statement Date:", statementDate } };

		for (String[] detail : details) {
			// Label
			contentStream.beginText();
			contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_NORMAL);
			contentStream.newLineAtOffset(MARGIN, yPosition);
			contentStream.showText(detail[0]);
			contentStream.endText();

			// Value
			contentStream.beginText();
			contentStream.setFont(PDType1Font.HELVETICA, FONT_SIZE_NORMAL);
			contentStream.newLineAtOffset(MARGIN + 130, yPosition);
			contentStream.showText(detail[1]);
			contentStream.endText();

			yPosition -= LINE_HEIGHT;
		}

		return yPosition - 15;
	}

	private float addTransactionSection(PDPageContentStream contentStream, float yPosition,
			PassbookResponseDTO passbookData) throws IOException {

		// Transaction header
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_HEADER);
		contentStream.newLineAtOffset(MARGIN, yPosition);
		contentStream.showText("Transaction History");
		contentStream.endText();

		yPosition -= 25;

		// Draw line under header
		contentStream.setLineWidth(1);
		contentStream.moveTo(MARGIN, yPosition);
		contentStream.lineTo(550, yPosition);
		contentStream.stroke();

		yPosition -= 15;

		// Check if transactions exist
		if (passbookData.getTransactions() == null || passbookData.getTransactions().isEmpty()) {
			contentStream.beginText();
			contentStream.setFont(PDType1Font.HELVETICA, FONT_SIZE_NORMAL);
			contentStream.newLineAtOffset(MARGIN + 150, yPosition);
			contentStream.showText("No transactions found for the specified period.");
			contentStream.endText();
			return yPosition - 30;
		}

		// Add table headers
		yPosition = addTransactionHeaders(contentStream, yPosition);

		// Add transaction data
		yPosition = addTransactionData(contentStream, yPosition, passbookData.getTransactions());

		// Add summary
		yPosition -= 20;
		addTransactionSummary(contentStream, yPosition, passbookData);

		return yPosition;
	}

	private float addTransactionHeaders(PDPageContentStream contentStream, float yPosition) throws IOException {
		String[] headers = { "Date", "Type", "Amount", "Balance" };
		float[] positions = { MARGIN, MARGIN + 80, MARGIN + 150, MARGIN + 220 };

		for (int i = 0; i < headers.length; i++) {
			contentStream.beginText();
			contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_NORMAL);
			contentStream.newLineAtOffset(positions[i], yPosition);
			contentStream.showText(headers[i]);
			contentStream.endText();
		}

		yPosition -= 15;

		// Draw line under headers
		contentStream.setLineWidth(0.5f);
		contentStream.moveTo(MARGIN, yPosition);
		contentStream.lineTo(400, yPosition);
		contentStream.stroke();

		return yPosition - 10;
	}

	private float addTransactionData(PDPageContentStream contentStream, float yPosition,
			List<PassbookTransactionResponseDTO> transactions) throws IOException {

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		float[] positions = { MARGIN, MARGIN + 80, MARGIN + 150, MARGIN + 220 };

		for (PassbookTransactionResponseDTO transaction : transactions) {
			// Check if we have enough space, if not, we would need a new page
			if (yPosition < 100) {
				contentStream.beginText();
				contentStream.setFont(PDType1Font.HELVETICA, 8);
				contentStream.newLineAtOffset(MARGIN, yPosition);
				contentStream.showText("... Statement continues (page limit reached)");
				contentStream.endText();
				break;
			}

			String[] rowData = { transaction.getDate() != null ? transaction.getDate().format(dateFormatter) : "N/A",
					transaction.getTranType() != null ? transaction.getTranType().toUpperCase() : "N/A",
					String.format("%.2f", transaction.getAmount() != null ? transaction.getAmount() : 0.0),
					String.format("%.2f",
							transaction.getBalanceAfterTransaction() != null ? transaction.getBalanceAfterTransaction()
									: 0.0) };

			for (int i = 0; i < rowData.length; i++) {
				contentStream.beginText();
				contentStream.setFont(PDType1Font.HELVETICA, 9);
				contentStream.newLineAtOffset(positions[i], yPosition);
				contentStream.showText(rowData[i]);
				contentStream.endText();
			}

			yPosition -= 12;
		}

		return yPosition;
	}

	private void addTransactionSummary(PDPageContentStream contentStream, float yPosition,
			PassbookResponseDTO passbookData) throws IOException {

		// Draw line above summary
		contentStream.setLineWidth(0.5f);
		contentStream.moveTo(MARGIN, yPosition + 10);
		contentStream.lineTo(400, yPosition + 10);
		contentStream.stroke();

		// Total transactions
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_NORMAL);
		contentStream.newLineAtOffset(MARGIN + 200, yPosition);
		contentStream.showText("Total Transactions: " + passbookData.getTotalTransactions());
		contentStream.endText();

		yPosition -= LINE_HEIGHT;

		// Current balance
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, FONT_SIZE_NORMAL);
		contentStream.newLineAtOffset(MARGIN + 200, yPosition);
		contentStream.showText("Current Balance: Rs " + String.format("%.2f",
				passbookData.getCurrentBalance() != null ? passbookData.getCurrentBalance() : 0.0));
		contentStream.endText();

		// Add disclaimer
		yPosition -= 40;
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_OBLIQUE, 8);
		contentStream.newLineAtOffset(MARGIN, yPosition);
		contentStream.showText("This is a computer-generated statement. For queries, contact customer care.");
		contentStream.endText();
	}
}