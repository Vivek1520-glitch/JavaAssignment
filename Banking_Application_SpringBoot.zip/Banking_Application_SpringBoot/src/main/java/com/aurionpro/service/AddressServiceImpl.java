package com.aurionpro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aurionpro.dto.AddressDTO;
import com.aurionpro.entity.Address;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.repo.AddressRepository;

@Transactional
@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepository addressRepository;

	@Override
	public AddressDTO createAddress(AddressDTO dto) {
		Address address = new Address();
		address.setCity(dto.getCity());
		address.setState(dto.getState());
		address.setPincode(dto.getPincode());
		Address saved = addressRepository.save(address);
		dto.setCity(saved.getCity());
		return dto;
	}

	@Override
	public AddressDTO updateAddress(Long id, AddressDTO dto) {
		Address address = addressRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Address not found"));
		address.setCity(dto.getCity());
		address.setState(dto.getState());
		address.setPincode(dto.getPincode());
		addressRepository.save(address);
		return dto;
	}

	@Override
	public AddressDTO getAddressById(Long id) {
		Address address = addressRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Address not found"));
		AddressDTO dto = new AddressDTO();
		dto.setCity(address.getCity());
		dto.setState(address.getState());
		dto.setPincode(address.getPincode());
		return dto;
	}

	@Override
	public void deleteAddress(Long id) {
		Address address = addressRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Address not found"));
		addressRepository.delete(address);
	}
}
