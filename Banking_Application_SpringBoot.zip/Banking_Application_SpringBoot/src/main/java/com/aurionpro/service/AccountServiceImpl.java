
package com.aurionpro.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.CustomerResponseAccountDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.exception.ResourceNotFoundException;
import com.aurionpro.exception.InvalidInputException;
import com.aurionpro.repo.AccountRepository;
import com.aurionpro.repo.CustomerRepository;

@Service("accountService")
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private EmailService emailService;

	private static final double SAVINGS_MIN_BALANCE = 1000.0;
	private static final double CURRENT_MIN_BALANCE = 0.0;
	private static final int MAX_ACCOUNTS_PER_CUSTOMER = 5;

	private String generateUniqueAccountNumber() {
		String accountNumber;
		do {
			long number = (long) (Math.random() * 1_000_000_000_000L);
			accountNumber = String.format("%012d", number); // exactly 12 digits
		} while (accountRepository.findByAccountNumber(accountNumber).isPresent());
		return accountNumber;
	}

	private CustomerResponseAccountDTO mapToCustomerResponseAccountDTO(Customer customer) {
		if (customer == null) {
			throw new InvalidInputException("Customer data is null");
		}
		CustomerResponseAccountDTO dto = new CustomerResponseAccountDTO();
		dto.setCustomerId(customer.getCustomerId());
		dto.setEmailId(customer.getEmailId());
		dto.setContactNo(customer.getContactNo());
		dto.setDob(customer.getDob());
		dto.setStatus(customer.getStatus());
		return dto;
	}

	@Override
	public AccountResponseDTO createAccount(AccountRequestDTO dto) {
		if (dto.getCustomerId() == null) {
			throw new InvalidInputException("Customer ID must be provided");
		}

		Customer customer = customerRepository.findById(dto.getCustomerId()).orElseThrow(
				() -> new ResourceNotFoundException("Customer with ID " + dto.getCustomerId() + " not found"));

		if (customer.getEmailId() == null || customer.getEmailId().isBlank()) {
			throw new InvalidInputException("Customer must have a valid email for account creation");
		}

		List<Account> existingAccounts = accountRepository.findByCustomerCustomerId(customer.getCustomerId());
		if (existingAccounts.size() >= MAX_ACCOUNTS_PER_CUSTOMER) {
			throw new InvalidInputException(
					"Customer already has maximum allowed accounts (" + MAX_ACCOUNTS_PER_CUSTOMER + ")");
		}

		if (dto.getAccountType() == null || dto.getAccountType().isBlank()) {
			throw new InvalidInputException("Account type must be provided");
		}
		String type = dto.getAccountType().toLowerCase();
		if (!type.equals("savings") && !type.equals("current")) {
			throw new InvalidInputException("Invalid account type. Allowed: savings or current");
		}

		double initialBalance = dto.getBalance() != null ? dto.getBalance() : 0.0;

		if (initialBalance % 100 != 0 && initialBalance % 500 != 0) {
			throw new InvalidInputException("Initial balance must be multiple of 100 or 500");
		}

		if (type.equals("savings") && initialBalance < SAVINGS_MIN_BALANCE) {
			throw new InvalidInputException("Savings account requires minimum balance ₹" + SAVINGS_MIN_BALANCE);
		}
		if (type.equals("current") && initialBalance < CURRENT_MIN_BALANCE) {
			throw new InvalidInputException("Current account cannot have negative initial balance");
		}

		Account account = new Account();
		account.setAccountNumber(generateUniqueAccountNumber());
		account.setAccountType(type);
		account.setBalance(initialBalance);
		account.setCustomer(customer);

		Account saved = accountRepository.save(account);

		emailService.sendAccountCreatedEmail(customer.getEmailId(), customer.getUser().getUsername(),
				saved.getAccountNumber());

		AccountResponseDTO response = new AccountResponseDTO();
		response.setAccountId(saved.getAccountId());
		response.setAccountNumber(saved.getAccountNumber());
		response.setAccountType(saved.getAccountType());
		response.setBalance(saved.getBalance());
		response.setCustomer(mapToCustomerResponseAccountDTO(saved.getCustomer()));
		return response;
	}

	@Override
	public AccountResponseDTO getAccountById(Long id) {
		if (id == null) {
			throw new InvalidInputException("Account ID must be provided");
		}
		Account account = accountRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Account with ID " + id + " not found"));

		AccountResponseDTO response = new AccountResponseDTO();
		response.setAccountId(account.getAccountId());
		response.setAccountNumber(account.getAccountNumber());
		response.setAccountType(account.getAccountType());
		response.setBalance(account.getBalance());
		response.setCustomer(mapToCustomerResponseAccountDTO(account.getCustomer()));
		return response;
	}

	@Override
	public AccountResponseDTO getAccountByNumber(String accountNumber) {
		Account account = accountRepository.findByAccountNumber(accountNumber)
				.orElseThrow(() -> new ResourceNotFoundException("Account not found with number: " + accountNumber));

		AccountResponseDTO dto = new AccountResponseDTO();
		dto.setAccountId(account.getAccountId());
		dto.setAccountNumber(account.getAccountNumber());
		dto.setAccountType(account.getAccountType());
		dto.setBalance(account.getBalance());
		dto.setCustomer(mapToCustomerResponseAccountDTO(account.getCustomer()));
		return dto;
	}

	@Override
	public List<AccountResponseDTO> getAccountsByCustomer(Long customerId) {
		if (customerId == null) {
			throw new InvalidInputException("Customer ID must be provided");
		}

		List<Account> accounts = accountRepository.findByCustomerCustomerId(customerId);
		if (accounts.isEmpty()) {
			throw new ResourceNotFoundException("No accounts found for Customer ID " + customerId);
		}

		return accounts.stream().map(account -> {
			AccountResponseDTO dto = new AccountResponseDTO();
			dto.setAccountId(account.getAccountId());
			dto.setAccountNumber(account.getAccountNumber());
			dto.setAccountType(account.getAccountType());
			dto.setBalance(account.getBalance());
			dto.setCustomer(mapToCustomerResponseAccountDTO(account.getCustomer()));
			return dto;
		}).collect(Collectors.toList());
	}

	@Override
	public List<AccountResponseDTO> getAllAccounts() {
		List<Account> accounts = accountRepository.findAll();
		if (accounts.isEmpty()) {
			throw new ResourceNotFoundException("No accounts found");
		}

		return accounts.stream().map(account -> {
			AccountResponseDTO dto = new AccountResponseDTO();
			dto.setAccountId(account.getAccountId());
			dto.setAccountNumber(account.getAccountNumber());
			dto.setAccountType(account.getAccountType());
			dto.setBalance(account.getBalance());
			dto.setCustomer(mapToCustomerResponseAccountDTO(account.getCustomer()));
			return dto;
		}).collect(Collectors.toList());
	}

	@Override
	public void deleteAccount(Long id) {
		if (id == null) {
			throw new InvalidInputException("Account ID must be provided");
		}
		Account account = accountRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Account with ID " + id + " not found"));

		if (account.getBalance() > 0) {
			throw new InvalidInputException("Cannot delete account with non-zero balance: ₹" + account.getBalance());
		}

		emailService.sendCustomerDeletedNotification(account.getCustomer().getEmailId(),
				account.getCustomer().getUser().getUsername());

		accountRepository.delete(account);
	}

	@Override
	public boolean isAccountOwner(Long accountId, String username) {
		Account acc = accountRepository.findById(accountId).orElse(null);
		if (acc != null && acc.getCustomer() != null && acc.getCustomer().getUser() != null) {
			return acc.getCustomer().getUser().getUsername().equals(username);
		}
		return false;
	}

	@Override
	public boolean isAccountNumberOwner(String accountNumber, String username) {
		Account acc = accountRepository.findByAccountNumber(accountNumber).orElse(null);
		if (acc != null && acc.getCustomer() != null && acc.getCustomer().getUser() != null) {
			return acc.getCustomer().getUser().getUsername().equals(username);
		}
		return false;
	}

	@Override
	public List<AccountResponseDTO> getAccountsByUsername(String username) {
		Customer customer = customerRepository.findByUser_Username(username)
				.orElseThrow(() -> new ResourceNotFoundException("Customer not found for username: " + username));

		return getAccountsByCustomer(customer.getCustomerId());
	}
}
