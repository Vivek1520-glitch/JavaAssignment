package com.aurionpro.service;

import java.util.List;
import com.aurionpro.dto.TransactionCreationResponseDTO;
import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;

public interface TransactionService {
    TransactionCreationResponseDTO createTransaction(TransactionRequestDTO dto);  // Changed return type
    List<TransactionResponseDTO> getTransactionsByAccountNumber(String accountNumber);
    List<TransactionResponseDTO> getTransactionsByCustomer(Long customerId);
    TransactionResponseDTO getTransactionById(Long transId);
    List<TransactionResponseDTO> getAllTransactions();
    boolean canAccessAccount(String accountNumber, String username);
    List<TransactionResponseDTO> getTransactionsByUsername(String username);
}