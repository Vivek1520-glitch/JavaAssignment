package com.aurionpro.service;

import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;

import java.util.List;

public interface CustomerService {
	CustomerResponseDTO createCustomer(CustomerRequestDTO dto);

	CustomerResponseDTO updateCustomer(Long id, CustomerUpdateDTO dto);

	CustomerResponseDTO getCustomerById(Long id);

	List<CustomerResponseDTO> getAllCustomers();

	void deleteCustomer(Long id);
}
