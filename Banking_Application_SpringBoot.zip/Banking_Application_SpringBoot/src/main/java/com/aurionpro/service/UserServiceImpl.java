package com.aurionpro.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.UserUpdateRequestDTO;
import com.aurionpro.dto.UserResponse2DTO;
import com.aurionpro.entity.User;
import com.aurionpro.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	// Helper method to convert Entity -> DTO
	private UserResponse2DTO mapToDTO(User u) {
		UserResponse2DTO dto = new UserResponse2DTO();
		dto.setUserId(u.getUserId());
		dto.setUsername(u.getUsername());
		dto.setPassword(u.getPassword());
		dto.setRoles(u.getRoles());
		dto.setCustomer(u.getCustomer());
		return dto;
	}

	@Override
	public List<UserResponse2DTO> getAllUsers() {
		List<User> users = userRepository.findAll();
		List<UserResponse2DTO> responseList = new ArrayList<>();

		for (User u : users) {
			responseList.add(mapToDTO(u));
		}

		return responseList;
	}

	@Override
	public UserResponse2DTO getUserById(Long userId) {
		Optional<User> searchedUser = userRepository.findById(userId);

		if (searchedUser.isPresent()) {
			return mapToDTO(searchedUser.get());
		} else {
			throw new RuntimeException("User not found with id: " + userId);
		}
	}

	@Override
	public UserResponse2DTO UpdateUserById(Long userId, UserUpdateRequestDTO userUpdateDTO) {
		Optional<User> searchedUser = userRepository.findById(userId);

		if (searchedUser.isPresent()) {
			User u = searchedUser.get();

			// Update only if values are not null
			if (userUpdateDTO.getUsername() != null) {
				u.setUsername(userUpdateDTO.getUsername());
			}
			if (userUpdateDTO.getPassword() != null) {
				u.setPassword(userUpdateDTO.getPassword());
			}
			if (userUpdateDTO.getRoles() != null) {
				u.setRoles(userUpdateDTO.getRoles());
			}
			// Removed customer update since your DTO doesn’t have it

			// Save updated user
			User updatedUser = userRepository.save(u);

			return mapToDTO(updatedUser);
		} else {
			throw new RuntimeException("User not found with id: " + userId);
		}
	}

	@Override
	public void DeleteUserById(Long userId) {
		if (!userRepository.existsById(userId)) {
			throw new RuntimeException("User not found with id: " + userId);
		}
		userRepository.deleteById(userId);
	}
}
