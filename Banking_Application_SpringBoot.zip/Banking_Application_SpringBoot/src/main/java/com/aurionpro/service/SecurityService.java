//package com.aurionpro.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.aurionpro.entity.Account;
//import com.aurionpro.entity.User;
//import com.aurionpro.exception.UnauthorizedAccessException;
//import com.aurionpro.repo.UserRepository;
//
//@Service("securityService")
//public class SecurityService {
//
//    @Autowired
//    private AccountService accountService;
//
//    @Autowired
//    private CustomerServiceImpl customerService;
//
//    // Check if the logged-in user owns the account
//    public boolean isAccountOwner(Long accountId, String username) {
//        return accountService.isAccountOwner(accountId, username);
//    }
//
//    // Check if the logged-in user owns the account by account number
//    public boolean isAccountNumberOwner(String accountNumber, String username) {
//        return accountService.isAccountNumberOwner(accountNumber, username);
//    }
//
//    // Check if the logged-in user owns the customer profile
//    public boolean isCustomerOwner(Long customerId, String username) {
//        return customerService.isCustomerOwner(customerId, username);
//    }
//
//    // Check if logged-in user matches a username
//    public boolean isUser(String username, String loggedInUsername) {
//        return username.equals(loggedInUsername);
//    }
//    
//    @Autowired
//    private UserRepository userRepository;
//
//    // Check if the logged-in user owns the account (or is admin)
//    public boolean canAccessAccount(Account account, String username) {
//        User currentUser = userRepository.findByUsername(username)
//                .orElseThrow(() -> new UnauthorizedAccessException("User not found"));
//
//        boolean isAdmin = currentUser.getRoles().stream()
//                .anyMatch(role -> role.getName().equalsIgnoreCase("ADMIN"));
//
//        if (isAdmin) return true;
//
//        if (currentUser.getCustomer() != null &&
//            currentUser.getCustomer().getCustomerId().equals(account.getCustomer().getCustomerId())) {
//            return true;
//        }
//
//        return false;
//    }
//}
