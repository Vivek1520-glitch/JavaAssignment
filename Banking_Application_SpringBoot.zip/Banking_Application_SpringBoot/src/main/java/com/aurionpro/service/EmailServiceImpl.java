package com.aurionpro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import com.aurionpro.dto.TransactionCreationResponseDTO;
import com.aurionpro.dto.PassbookResponseDTO;
import com.aurionpro.exception.EmailSendingException;

import jakarta.activation.DataSource;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.util.ByteArrayDataSource;
import java.time.format.DateTimeFormatter;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private PdfService pdfService;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${app.name:V_BANKING}")
    private String appName;

    @Override
    public void sendWelcomeEmail(String toEmail, String customerName) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("Welcome to " + appName + "!");

            String htmlContent = buildWelcomeEmailContent(customerName);
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send welcome email to: " + toEmail);
        }
    }

    @Override
    public void sendAccountCreatedEmail(String toEmail, String customerName, String accountNumber) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("New Account Created - " + appName);

            String htmlContent = buildAccountCreatedEmailContent(customerName, accountNumber);
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send account creation email to: " + toEmail);
        }
    }

    @Override
    public void sendTransactionNotification(String toEmail, TransactionCreationResponseDTO transaction, String customerName) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("Transaction Alert - " + appName);

            String htmlContent = buildTransactionNotificationContent(transaction, customerName);
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send transaction notification to: " + toEmail);
        }
    }

    @Override
    public void sendPasswordResetEmail(String toEmail, String resetToken) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("Password Reset - " + appName);
            message.setText("Your password reset token is: " + resetToken + 
                          "\nThis token is valid for 15 minutes." +
                          "\n\nIf you didn't request this reset, please ignore this email.");

            mailSender.send(message);
        } catch (Exception e) {
            throw new EmailSendingException("Failed to send password reset email to: " + toEmail);
        }
    }

    @Override
    public void sendCustomerDeletedNotification(String toEmail, String customerName) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("Account Closure Notification - " + appName);
            message.setText("Dear " + customerName + ",\n\n" +
                          "Your account with " + appName + " has been closed as requested.\n" +
                          "All your data has been removed from our system.\n\n" +
                          "Thank you for banking with us.\n\n" +
                          "Regards,\n" + appName + " Team");

            mailSender.send(message);
        } catch (Exception e) {
            throw new EmailSendingException("Failed to send account deletion notification to: " + toEmail);
        }
    }

    @Override
    public void sendPassbookEmail(String toEmail, String customerName, PassbookResponseDTO passbookData) {
        try {
            if (toEmail == null || toEmail.trim().isEmpty()) {
                throw new EmailSendingException("Email address cannot be null or empty");
            }
            
            if (passbookData == null) {
                throw new EmailSendingException("Passbook data cannot be null");
            }
            
            if (passbookData.getGeneratedAt() == null) {
                passbookData.setGeneratedAt(java.time.LocalDateTime.now());
            }
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("Account Statement - " + appName);

            byte[] pdfBytes;
            try {
                pdfBytes = pdfService.generatePassbookPdf(passbookData);
                
                if (pdfBytes == null || pdfBytes.length == 0) {
                    throw new EmailSendingException("Generated PDF is empty");
                }
                
            } catch (Exception e) {
                throw new EmailSendingException("Failed to generate PDF: " + e.getMessage());
            }
            
            String fileName = "Statement_" + 
                             (passbookData.getAccountNumber() != null ? passbookData.getAccountNumber() : "Account") + 
                             "_" + 
                             passbookData.getGeneratedAt().format(DateTimeFormatter.ofPattern("ddMMyyyy")) + 
                             ".pdf";
            
            DataSource dataSource = new ByteArrayDataSource(pdfBytes, "application/pdf");
            helper.addAttachment(fileName, dataSource);

            String htmlContent = buildPassbookEmailContent(
                customerName != null ? customerName : "Valued Customer", 
                passbookData
            );
            helper.setText(htmlContent, true);

            mailSender.send(message);
            
            System.out.println("Passbook email sent successfully to: " + toEmail);
            
        } catch (EmailSendingException e) {
            throw e;
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send passbook email due to messaging error: " + e.getMessage());
        } catch (Exception e) {
            throw new EmailSendingException("Unexpected error while sending passbook email: " + e.getMessage());
        }
    }

    @Override
    public void sendAccountUpdatedEmail(String toEmail, String customerName) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject("Account Updated - " + appName);

            String htmlContent = buildAccountUpdatedEmailContent(customerName);
            helper.setText(htmlContent, true);

            mailSender.send(message);
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send account update email to: " + toEmail);
        }
    }

    private String buildWelcomeEmailContent(String customerName) {
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />" +
               "<style>" +
               "body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }" +
               ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
               ".header { background-color: #007bff; color: white; padding: 20px; text-align: center; }" +
               ".content { padding: 30px; background-color: #f8f9fa; }" +
               ".footer { background-color: #6c757d; color: white; padding: 10px; text-align: center; }" +
               "</style></head>" +
               "<body>" +
               "<div class='container'>" +
               "<div class='header'>" +
               "<h1>Welcome to " + appName + "!</h1>" +
               "</div>" +
               "<div class='content'>" +
               "<h2>Dear " + customerName + ",</h2>" +
               "<p>Thank you for choosing " + appName + ". We're excited to have you as our customer!</p>" +
               "<p>Your account has been successfully created. You can now:</p>" +
               "<ul>" +
               "<li>Please wait till bank approves your registration details</li>" +
               "<li>Perform transactions</li>" +
               "<li>View transaction history</li>" +
               "<li>Manage your profile</li>" +
               "</ul>" +
               "<p>If you have any questions, please don't hesitate to contact our support team Email:vivek.m.shinde1520@gmail.com.</p>" +
               "<p>Happy Banking!</p>" +
               "</div>" +
               "<div class='footer'>" +
               "<p>&copy; 2025 " + appName + ". All rights reserved.</p>" +
               "</div>" +
               "</div>" +
               "</body>" +
               "</html>";
    }

    private String buildAccountCreatedEmailContent(String customerName, String accountNumber) {
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />" +
               "<style>" +
               "body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }" +
               ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
               ".header { background-color: #28a745; color: white; padding: 20px; text-align: center; }" +
               ".content { padding: 30px; background-color: #f8f9fa; }" +
               ".account-details { background-color: #e9ecef; padding: 20px; border-radius: 5px; margin: 20px 0; }" +
               ".footer { background-color: #6c757d; color: white; padding: 10px; text-align: center; }" +
               "</style></head>" +
               "<body>" +
               "<div class='container'>" +
               "<div class='header'>" +
               "<h1>New Account Created!</h1>" +
               "</div>" +
               "<div class='content'>" +
               "<h2>Dear " + customerName + ",</h2>" +
               "<p>Congratulations! Your new bank account has been successfully created.</p>" +
               "<div class='account-details'>" +
               "<h3>Account Details:</h3>" +
               "<p><strong>Account Number:</strong> " + accountNumber + "</p>" +
               "<p><strong>Status:</strong> Active</p>" +
               "</div>" +
               "<p>You can now start using your account for transactions. Please keep your account details secure.</p>" +
               "<p>Thank you for banking with us!</p>" +
               "</div>" +
               "<div class='footer'>" +
               "<p>&copy; 2025 " + appName + ". All rights reserved.</p>" +
               "</div>" +
               "</div>" +
               "</body>" +
               "</html>";
    }

    private String buildTransactionNotificationContent(TransactionCreationResponseDTO transaction, String customerName) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String transactionColor = transaction.getTranType().equalsIgnoreCase("credit") ? "#28a745" : "#dc3545";

        String formattedAmount = "₹ " + String.format("%.2f", transaction.getAmount());

        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />" +
               "<style>" +
               "body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }" +
               ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
               ".header { background-color: " + transactionColor + "; color: white; padding: 20px; text-align: center; }" +
               ".content { padding: 30px; background-color: #f8f9fa; }" +
               ".transaction-details { background-color: #e9ecef; padding: 20px; border-radius: 5px; margin: 20px 0; }" +
               ".amount { font-size: 24px; font-weight: bold; color: " + transactionColor + "; }" +
               ".footer { background-color: #6c757d; color: white; padding: 10px; text-align: center; }" +
               "</style></head>" +
               "<body>" +
               "<div class='container'>" +
               "<div class='header'>" +
               "<h1>Transaction Alert</h1>" +
               "</div>" +
               "<div class='content'>" +
               "<h2>Dear " + customerName + ",</h2>" +
               "<p>A transaction has been processed on your account:</p>" +
               "<div class='transaction-details'>" +
               "<h3>Transaction Details:</h3>" +
               "<p><strong>Transaction ID:</strong> " + transaction.getTransId() + "</p>" +
               "<p><strong>Type:</strong> " + transaction.getTranType().toUpperCase() + "</p>" +
               "<p><strong>Amount:</strong> <span class='amount'>" + formattedAmount + "</span></p>" +
               "<p><strong>Date:</strong> " + transaction.getDate().format(formatter) + "</p>" +
               "<p><strong>Account Balance:</strong> ₹ " + String.format("%.2f", transaction.getBalanceAfterTransaction()) + "</p>" +
               (transaction.getDescription() != null ? "<p><strong>Description:</strong> " + transaction.getDescription() + "</p>" : "") +
               (transaction.getToAccountNumber() != null ? "<p><strong>To Account:</strong> " + transaction.getToAccountNumber() + "</p>" : "") +
               "</div>" +
               "<p>If you did not authorize this transaction, please contact us immediately at vivek.m.shinde1520@gmail.com</p>" +
               "<p>Thank you for banking with us!</p>" +
               "</div>" +
               "<div class='footer'>" +
               "<p>&copy; 2025 " + appName + ". All rights reserved.</p>" +
               "</div>" +
               "</div>" +
               "</body>" +
               "</html>";
    }


    private String buildPassbookEmailContent(String customerName, PassbookResponseDTO passbookData) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />" +
               "<style>" +
               "body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }" +
               ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
               ".header { background-color: #17a2b8; color: white; padding: 20px; text-align: center; }" +
               ".content { padding: 30px; background-color: #f8f9fa; }" +
               ".statement-info { background-color: #e9ecef; padding: 20px; border-radius: 5px; margin: 20px 0; }" +
               ".footer { background-color: #6c757d; color: white; padding: 10px; text-align: center; }" +
               "</style></head>" +
               "<body>" +
               "<div class='container'>" +
               "<div class='header'>" +
               "<h1>Account Statement</h1>" +
               "</div>" +
               "<div class='content'>" +
               "<h2>Dear " + customerName + ",</h2>" +
               "<p>Please find your account statement attached as a PDF document.</p>" +
               "<div class='statement-info'>" +
               "<h3>Statement Summary:</h3>" +
               "<p><strong>Account Number:</strong> " + passbookData.getAccountNumber() + "</p>" +
               "<p><strong>Account Type:</strong> " + passbookData.getAccountType() + "</p>" +
               "<p><strong>Current Balance:</strong> Rs. " + String.format("%.2f", passbookData.getCurrentBalance()) + "</p>" +
               "<p><strong>Total Transactions:</strong> " + passbookData.getTotalTransactions() + "</p>" +
               "<p><strong>Statement Generated:</strong> " + passbookData.getGeneratedAt().format(formatter) + "</p>" +
               "</div>" +
               "<p>The detailed statement is available in the PDF attachment. Please save it for your records.</p>" +
               "<p><strong>Important:</strong> This statement is confidential. Please do not share it with unauthorized persons.</p>" +
               "<p>If you have any questions regarding your statement, please contact our customer support.</p>" +
               "<p>Thank you for banking with us!</p>" +
               "</div>" +
               "<div class='footer'>" +
               "<p>&copy; 2025 " + appName + ". All rights reserved.</p>" +
               "</div>" +
               "</div>" +
               "</body>" +
               "</html>";
    }

    private String buildAccountUpdatedEmailContent(String customerName) {
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />" +
               "<style>" +
               "body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }" +
               ".container { max-width: 600px; margin: 0 auto; padding: 20px; }" +
               ".header { background-color: #17a2b8; color: white; padding: 20px; text-align: center; }" +
               ".content { padding: 30px; background-color: #f8f9fa; }" +
               ".footer { background-color: #6c757d; color: white; padding: 10px; text-align: center; }" +
               "</style></head>" +
               "<body>" +
               "<div class='container'>" +
               "<div class='header'>" +
               "<h1>Account Updated</h1>" +
               "</div>" +
               "<div class='content'>" +
               "<h2>Dear " + customerName + ",</h2>" +
               "<p>Your account information has been successfully updated.</p>" +
               "<p>If you did not make these changes, please contact our support team immediately.</p>" +
               "<p>Thank you for banking with us!</p>" +
               "</div>" +
               "<div class='footer'>" +
               "<p>&copy; 2025 " + appName + ". All rights reserved.</p>" +
               "</div>" +
               "</div>" +
               "</body>" +
               "</html>";
    }
}