package com.aurionpro.service;

import org.springframework.security.core.Authentication;

import com.aurionpro.dto.PassbookRequestDTO;
import com.aurionpro.dto.PassbookRequestOptionalDTO;
import com.aurionpro.dto.PassbookResponseDTO;

public interface PassbookService {

	PassbookResponseDTO getPassbook(PassbookRequestDTO request);

	PassbookResponseDTO getPassbookByAccountNumber(String accountNumber);

	 PassbookResponseDTO getCustomerPassbook(Long accountId, Authentication authentication);


	PassbookResponseDTO getPassbookForLoggedInCustomer(String username, PassbookRequestOptionalDTO request);
}
