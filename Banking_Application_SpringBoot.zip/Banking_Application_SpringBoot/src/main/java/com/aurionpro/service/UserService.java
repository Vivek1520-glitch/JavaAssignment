package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.UserResponse2DTO;
import com.aurionpro.dto.UserUpdateRequestDTO;

public interface UserService {

	public List<UserResponse2DTO> getAllUsers();

	public UserResponse2DTO getUserById(Long userId);

	public UserResponse2DTO UpdateUserById(Long userId, UserUpdateRequestDTO userUpdateDTO);

	public void DeleteUserById(Long userId);

}
