package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;

public interface AccountService {
	AccountResponseDTO createAccount(AccountRequestDTO dto);

	AccountResponseDTO getAccountById(Long id);

	AccountResponseDTO getAccountByNumber(String accountNumber);

	List<AccountResponseDTO> getAccountsByCustomer(Long customerId);

	List<AccountResponseDTO> getAllAccounts();

	void deleteAccount(Long id);

	boolean isAccountOwner(Long accountId, String username);

	boolean isAccountNumberOwner(String accountNumber, String username);

	List<AccountResponseDTO> getAccountsByUsername(String username);
}