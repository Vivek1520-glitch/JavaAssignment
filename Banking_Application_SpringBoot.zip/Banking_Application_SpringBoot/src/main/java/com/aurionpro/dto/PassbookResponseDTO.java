package com.aurionpro.dto;

import java.time.LocalDateTime;
import java.util.List;

public class PassbookResponseDTO {
	private Long accountId;
	private String accountNumber;
	private String accountType;
	private Double currentBalance;
	private String customerName; // from User
	private String customerEmail;
	private LocalDateTime generatedAt;
	private List<PassbookTransactionResponseDTO> transactions;
	private int totalTransactions;

	public PassbookResponseDTO() {
		this.generatedAt = LocalDateTime.now();
	}

	
	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public LocalDateTime getGeneratedAt() {
		return generatedAt;
	}

	public void setGeneratedAt(LocalDateTime generatedAt) {
		this.generatedAt = generatedAt;
	}

	public List<PassbookTransactionResponseDTO> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<PassbookTransactionResponseDTO> transactionDTOs) {
		this.transactions = transactionDTOs;
		this.totalTransactions = transactionDTOs != null ? transactionDTOs.size() : 0;
	}

	public int getTotalTransactions() {
		return totalTransactions;
	}

	public void setTotalTransactions(int totalTransactions) {
		this.totalTransactions = totalTransactions;
	}

	@Override
	public String toString() {
		return "PassbookResponseDTO{" + "accountId=" + accountId + ", accountNumber='" + accountNumber + '\''
				+ ", accountType='" + accountType + '\'' + ", currentBalance=" + currentBalance + ", customerName='"
				+ customerName + '\'' + ", customerEmail='" + customerEmail + '\'' + ", generatedAt=" + generatedAt
				+ ", totalTransactions=" + totalTransactions + '}';
	}
}
