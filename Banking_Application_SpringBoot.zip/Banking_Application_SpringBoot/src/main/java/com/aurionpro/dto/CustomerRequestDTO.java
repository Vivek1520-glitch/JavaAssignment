package com.aurionpro.dto;

import java.time.LocalDate;
import jakarta.validation.constraints.*;

public class CustomerRequestDTO {

   
    @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters")
    private String username;

  
    @Size(min = 6, max = 20, message = "Password must be between 6 and 20 characters")
    private String password;

    //@NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String emailId;

    //@NotBlank(message = "Contact number is required")
    @Pattern(regexp = "\\d{10}", message = "Contact number must be exactly 10 digits")
    private String contactNo;

    //@NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    private LocalDate dob;

    //@NotNull(message = "Address is required")
    private AddressDTO address;

    public CustomerRequestDTO() {}

    public CustomerRequestDTO(String username, String password, String emailId, String contactNo, LocalDate dob, AddressDTO address) {
        this.username = username;
        this.password = password;
        this.emailId = emailId;
        this.contactNo = contactNo;
        this.dob = dob;
        this.address = address;
    }

  
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public AddressDTO getAddress() {
        return address;
    }

    public void setAddress(AddressDTO address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "CustomerRequestDTO{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", emailId='" + emailId + '\'' +
                ", contactNo='" + contactNo + '\'' +
                ", dob=" + dob +
                ", address=" + address +
                '}';
    }
}
