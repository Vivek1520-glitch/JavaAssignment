package com.aurionpro.dto;

import java.time.LocalDate;

public class PassbookTransactionRequestDTO {

    private LocalDate fromDate; // Optional
    private LocalDate toDate;   // Optional

    public PassbookTransactionRequestDTO() {}

    public PassbookTransactionRequestDTO(LocalDate fromDate, LocalDate toDate) {
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    @Override
    public String toString() {
        return "PassbookTransactionRequestDTO{" +
                "fromDate=" + fromDate +
                ", toDate=" + toDate +
                '}';
    }
}
