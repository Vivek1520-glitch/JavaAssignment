package com.aurionpro.dto;

import java.time.LocalDate;

import com.aurionpro.entity.Customer.CustomerStatus;

public class CustomerResponseDTO {

    private Long customerId;
    private String emailId;
    private String contactNo;
    private LocalDate dob;
    private CustomerStatus status;
    private AddressDTO address;
    private Long userId;
    private String username;

    // Default constructor
    public CustomerResponseDTO() {}

    // Constructor to map directly from Customer entity
    public CustomerResponseDTO(Long customerId, String emailId, String contactNo, LocalDate dob,
                               CustomerStatus status, AddressDTO address, Long userId, String username) {
        this.customerId = customerId;
        this.emailId = emailId;
        this.contactNo = contactNo;
        this.dob = dob;
        this.status = status;
        this.address = address;
        this.userId = userId;
        this.username = username;
    }

    // Getters and setters
    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getEmailId() { return emailId; }
    public void setEmailId(String emailId) { this.emailId = emailId; }

    public String getContactNo() { return contactNo; }
    public void setContactNo(String contactNo) { this.contactNo = contactNo; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public CustomerStatus getStatus() { return status; }
    public void setStatus(CustomerStatus status) { this.status = status; }

    public AddressDTO getAddress() { return address; }
    public void setAddress(AddressDTO address) { this.address = address; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

}
