package com.aurionpro.dto;

import jakarta.validation.constraints.*;

public class AccountRequestDTO {

	
	private String accountNumber;

	@NotBlank(message = "Account type is required")
	private String accountType;

	@NotNull(message = "Balance is required")
	@PositiveOrZero(message = "Balance cannot be negative")
	private Double balance;

	@NotNull(message = "Customer Id must not be null")
	@Positive(message = "Customer Id must be a positive number")
	private Long customerId;

	public AccountRequestDTO() {
	}

	public AccountRequestDTO(String accountNumber, String accountType, Double balance, Long customerId) {
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.balance = balance;
		this.customerId = customerId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "AccountRequestDTO{" + "accountNumber='" + accountNumber + '\'' + ", accountType='" + accountType + '\''
				+ ", balance=" + balance + ", customerId=" + customerId + '}';
	}
}
