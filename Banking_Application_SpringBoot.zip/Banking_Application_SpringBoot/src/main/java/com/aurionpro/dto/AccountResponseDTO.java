package com.aurionpro.dto;

import java.time.LocalDate;

public class AccountResponseDTO {

    private Long accountId;
    private String accountNumber;
    private String accountType;
    private Double balance;
    private CustomerResponseAccountDTO customer; 

  
    public AccountResponseDTO() {
    }

 
    public AccountResponseDTO(Long accountId, String accountNumber, String accountType, 
                              Double balance, CustomerResponseAccountDTO customer) {
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
        this.customer = customer;
    }

 
    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public CustomerResponseAccountDTO getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerResponseAccountDTO customer) {
		this.customer = customer;
	}

	public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

  

    @Override
    public String toString() {
        return "AccountResponseDTO{" +
                "accountId=" + accountId +
                ", accountNumber='" + accountNumber + '\'' +
                ", accountType='" + accountType + '\'' +
                ", balance=" + balance +
                ", customer=" + customer +
                '}';
    }
}
