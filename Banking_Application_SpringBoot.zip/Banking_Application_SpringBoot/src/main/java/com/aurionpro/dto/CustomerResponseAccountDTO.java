package com.aurionpro.dto;

import java.time.LocalDate;

import com.aurionpro.entity.Customer.CustomerStatus;

public class CustomerResponseAccountDTO {

	private Long customerId;
	private String emailId;
	private String contactNo;
	private LocalDate dob;
	private CustomerStatus status;

	public CustomerResponseAccountDTO() {
	}

	public CustomerResponseAccountDTO(Long customerId, String emailId, String contactNo, LocalDate dob,
			CustomerStatus status, AddressDTO address, Long userId, String username) {
		this.customerId = customerId;
		this.emailId = emailId;
		this.contactNo = contactNo;
		this.dob = dob;
		this.status = status;

	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public CustomerStatus getStatus() {
		return status;
	}

	public void setStatus(CustomerStatus status) {
		this.status = status;
	}

}
