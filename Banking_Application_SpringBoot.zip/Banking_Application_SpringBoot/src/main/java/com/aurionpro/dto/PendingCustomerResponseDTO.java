package com.aurionpro.dto;

import com.aurionpro.entity.Customer.CustomerStatus;

public class PendingCustomerResponseDTO {

    private Long customerId;
    private Long userId;
    private String username;
    private CustomerStatus status;

    // Constructors
    public PendingCustomerResponseDTO() {}

    public PendingCustomerResponseDTO(Long customerId, Long userId, String username, CustomerStatus status) {
        this.customerId = customerId;
        this.userId = userId;
        this.username = username;
        this.status = status;
    }

    // Getters and Setters
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public CustomerStatus getStatus() {
        return status;
    }

    public void setStatus(CustomerStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "PendingCustomerResponseDTO{" +
                "customerId=" + customerId +
                ", userId=" + userId +
                ", username='" + username + '\'' +
                ", status=" + status +
                '}';
    }
}
