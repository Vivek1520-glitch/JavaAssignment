package com.aurionpro.dto;

import java.time.LocalDate;
import jakarta.validation.constraints.NotNull;

public class PassbookRequestDTO {
	@NotNull(message = "Account ID is required")
	private Long accountId;

	private LocalDate fromDate;
	private LocalDate toDate; 

	public PassbookRequestDTO() {
	}

	public PassbookRequestDTO(Long accountId, LocalDate fromDate, LocalDate toDate) {
		this.accountId = accountId;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	@Override
	public String toString() {
		return "PassbookRequestDTO{" + "accountId=" + accountId + ", fromDate=" + fromDate + ", toDate=" + toDate + '}';
	}
}
