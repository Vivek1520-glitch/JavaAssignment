package com.aurionpro.dto;

import java.time.LocalDateTime;

public class PassbookTransactionResponseDTO {
    
    private Long transId;
    private String tranType;
    private Double amount;
    private LocalDateTime date;
    private Double balanceAfterTransaction;
    private String description;
    private String referenceNumber;

    public PassbookTransactionResponseDTO() {
    }

    public PassbookTransactionResponseDTO(Long transId, String tranType, Double amount, 
                                        LocalDateTime date, Double balanceAfterTransaction) {
        this.transId = transId;
        this.tranType = tranType;
        this.amount = amount;
        this.date = date;
        this.balanceAfterTransaction = balanceAfterTransaction;
    }

    // Getters and Setters
    public Long getTransId() {
        return transId;
    }

    public void setTransId(Long transId) {
        this.transId = transId;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Double getBalanceAfterTransaction() {
        return balanceAfterTransaction;
    }

    public void setBalanceAfterTransaction(Double balanceAfterTransaction) {
        this.balanceAfterTransaction = balanceAfterTransaction;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    @Override
    public String toString() {
        return "PassbookTransactionResponseDTO{" +
                "transId=" + transId +
                ", tranType='" + tranType + '\'' +
                ", amount=" + amount +
                ", date=" + date +
                ", balanceAfterTransaction=" + balanceAfterTransaction +
                ", description='" + description + '\'' +
                ", referenceNumber='" + referenceNumber + '\'' +
                '}';
    }
}