package com.aurionpro.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CustomerUpdateDTO {

   
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;

    @Size(min = 6, message = "Password must be at least 6 characters") // optional but validated if present
    private String password;

  
    @Email(message = "Invalid email format")
    private String emailId;

 
    @Pattern(regexp = "^[0-9]{10}$", message = "Contact number must be 10 digits")
    private String contactNo;


    @Past(message = "Date of birth must be in the past")
    private LocalDate dob;

  
    private AddressDTO address;

    public CustomerUpdateDTO() {
    }

    public CustomerUpdateDTO(String username, String password, String emailId,
                             String contactNo, LocalDate dob, AddressDTO address) {
        this.username = username;
        this.password = password;
        this.emailId = emailId;
        this.contactNo = contactNo;
        this.dob = dob;
        this.address = address;
    }

    // Getters and setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmailId() { return emailId; }
    public void setEmailId(String emailId) { this.emailId = emailId; }

    public String getContactNo() { return contactNo; }
    public void setContactNo(String contactNo) { this.contactNo = contactNo; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public AddressDTO getAddress() { return address; }
    public void setAddress(AddressDTO address) { this.address = address; }
}