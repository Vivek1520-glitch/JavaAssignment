package com.aurionpro.security;

import java.util.Date;
import java.util.stream.Collectors;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.aurionpro.exception.UnauthorizedAccessException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtTokenProvider {

	@Value("${app.jwt-secret}")
	private String jwtSecret;

	@Value("${app.jwt-expiration-milliseconds}")
	private long jwtExpirationMilliseconds;

	public String generateToken(Authentication authentication) {
		String username = authentication.getName();
		Date now = new Date();
		Date expiryDate = new Date(now.getTime() + jwtExpirationMilliseconds);

		String roles = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority)
				.collect(Collectors.joining(","));

		return Jwts.builder().setSubject(username).setIssuedAt(now).setExpiration(expiryDate).claim("roles", roles)
				.signWith(getSigningKey()).compact();
	}

	private SecretKey getSigningKey() {

		return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
	}

	public String getUsername(String token) {
		Claims claims = Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody();
		return claims.getSubject();
	}

	public String getRoles(String token) {
		Claims claims = Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody();
		return claims.get("roles", String.class);
	}

	public boolean validateToken(String token) {
		try {
			Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
			return true;
		} catch (MalformedJwtException ex) {
			System.err.println("Invalid JWT token: " + ex.getMessage());
			return false;
		} catch (ExpiredJwtException ex) {
			System.err.println("Expired JWT token: " + ex.getMessage());
			return false;
		} catch (UnsupportedJwtException ex) {
			System.err.println("Unsupported JWT token: " + ex.getMessage());
			return false;
		} catch (IllegalArgumentException ex) {
			System.err.println("JWT claims string is empty: " + ex.getMessage());
			return false;
		} catch (Exception ex) {
			System.err.println("JWT validation error: " + ex.getMessage());
			return false;
		}
	}
}