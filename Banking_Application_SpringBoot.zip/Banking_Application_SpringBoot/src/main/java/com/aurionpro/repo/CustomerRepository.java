package com.aurionpro.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Customer.CustomerStatus;
import com.aurionpro.entity.User;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	Optional<Customer> findByEmailId(String emailId);

	Optional<Customer> findByUser_Username(String username);

	Optional<Customer> findByUser(User user);

	List<Customer> findByStatus(CustomerStatus status);

	boolean existsByEmailId(String emailId);
}