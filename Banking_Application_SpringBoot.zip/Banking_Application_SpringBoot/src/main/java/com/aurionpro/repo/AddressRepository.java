package com.aurionpro.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.aurionpro.entity.Address;
import com.aurionpro.entity.Customer;
import java.util.Optional;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
