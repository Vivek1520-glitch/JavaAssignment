package com.aurionpro.repo;

import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
	List<Account> findByCustomerCustomerId(Long customerId);

	Optional<Account> findByAccountNumber(String accountNumber);

}
