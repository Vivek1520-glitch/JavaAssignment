package com.aurionpro.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.aurionpro.entity.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {


	List<Transaction> findByAccountAccountId(Long accountId);

	List<Transaction> findByCustomerCustomerId(Long customerId);

	List<Transaction> findByAccountAccountIdAndDateBetween(Long accountId, LocalDateTime from, LocalDateTime to);

	List<Transaction> findByCustomer_CustomerIdOrderByDateDesc(Long customerId);

	List<Transaction> findByAccount_AccountIdOrderByDateDesc(Long accountId);

	List<Transaction> findByAccount_AccountIdAndDateBetweenOrderByDateDesc(Long accountId, LocalDateTime from,
			LocalDateTime to);



	
	@Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t "
			+ "WHERE t.account.accountId = :accountId AND t.tranType IN ('debit','transfer') "
			+ "AND t.date >= :startOfDay AND t.date <= :endOfDay")
	double sumTransactionsToday(@Param("accountId") Long accountId, @Param("startOfDay") LocalDateTime startOfDay,
			@Param("endOfDay") LocalDateTime endOfDay);


	@Query("SELECT COUNT(t) FROM Transaction t " + "WHERE t.account.accountId = :accountId "
			+ "AND t.date >= :startOfDay AND t.date <= :endOfDay")
	int countTransactionsToday(@Param("accountId") Long accountId, @Param("startOfDay") LocalDateTime startOfDay,
			@Param("endOfDay") LocalDateTime endOfDay);

	
	@Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t "
			+ "WHERE t.account.accountId = :accountId AND t.tranType = 'transfer' "
			+ "AND t.date >= :startOfDay AND t.date <= :endOfDay")
	double sumTransfersToday(@Param("accountId") Long accountId);
}
