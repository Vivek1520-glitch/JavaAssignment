package com.aurionpro.entity;

import java.time.LocalDate;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "customers")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;

	private String emailId;
	private String contactNo;
	private LocalDate dob;

	@Enumerated(EnumType.STRING)
	private CustomerStatus status = CustomerStatus.PENDING;

	public enum CustomerStatus {
		PENDING, APPROVED, REJECTED
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private User user;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	private Address address;

	@OneToMany(mappedBy = "customer", cascade = {
	        CascadeType.PERSIST,
	        CascadeType.MERGE,
	        CascadeType.REFRESH
	        
	})
	private List<Account> accounts;

	@OneToMany(mappedBy = "customer", cascade = {
	        CascadeType.PERSIST,
	        CascadeType.MERGE,
	        CascadeType.REFRESH,
	      
	})
	private List<Transaction> transactions;

	public Customer() {
	}

	public Customer(User user) {
		this.user = user;
		this.status = CustomerStatus.PENDING;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public CustomerStatus getStatus() {
		return status;
	}

	public void setStatus(CustomerStatus status) {
		this.status = status;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
