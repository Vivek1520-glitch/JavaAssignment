package com.aurionpro.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.CustomerResponseAccountDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.exception.InvalidInputException;

public class AccountMapper {

    // ✅ Convert Customer -> CustomerResponseAccountDTO
    public static CustomerResponseAccountDTO toCustomerResponseAccountDTO(Customer customer) {
        if (customer == null) {
            throw new InvalidInputException("Customer data is null");
        }
        CustomerResponseAccountDTO dto = new CustomerResponseAccountDTO();
        dto.setCustomerId(customer.getCustomerId());
        dto.setEmailId(customer.getEmailId());
        dto.setContactNo(customer.getContactNo());
        dto.setDob(customer.getDob());
        dto.setStatus(customer.getStatus());
        return dto;
    }

    // ✅ Convert Account -> AccountResponseDTO
    public static AccountResponseDTO toAccountResponseDTO(Account account) {
        if (account == null) {
            throw new InvalidInputException("Account data is null");
        }
        AccountResponseDTO dto = new AccountResponseDTO();
        dto.setAccountId(account.getAccountId());
        dto.setAccountNumber(account.getAccountNumber());
        dto.setAccountType(account.getAccountType());
        dto.setBalance(account.getBalance());
        dto.setCustomer(toCustomerResponseAccountDTO(account.getCustomer()));
        return dto;
    }

    // ✅ Convert List<Account> -> List<AccountResponseDTO>
    public static List<AccountResponseDTO> toAccountResponseDTOList(List<Account> accounts) {
        return accounts.stream()
                       .map(AccountMapper::toAccountResponseDTO)
                       .collect(Collectors.toList());
    }
}
