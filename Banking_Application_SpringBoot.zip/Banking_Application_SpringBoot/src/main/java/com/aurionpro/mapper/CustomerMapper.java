package com.aurionpro.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.aurionpro.dto.AddressDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.PendingCustomerResponseDTO;
import com.aurionpro.entity.Address;
import com.aurionpro.entity.Customer;
import com.aurionpro.exception.InvalidRequestException;

public class CustomerMapper {

    // 🔹 Map Address -> AddressDTO
    public static AddressDTO toAddressDTO(Address address) {
        if (address == null) return null;

        AddressDTO dto = new AddressDTO();
        dto.setCity(address.getCity());
        dto.setState(address.getState());
        dto.setPincode(address.getPincode());
        return dto;
    }

    // 🔹 Map Customer -> CustomerResponseDTO
    public static CustomerResponseDTO toCustomerResponseDTO(Customer customer) {
        if (customer == null) {
            throw new InvalidRequestException("Customer entity is null");
        }

        CustomerResponseDTO dto = new CustomerResponseDTO();
        dto.setCustomerId(customer.getCustomerId());
        dto.setEmailId(customer.getEmailId());
        dto.setContactNo(customer.getContactNo());
        dto.setDob(customer.getDob());
        dto.setStatus(customer.getStatus());

        if (customer.getAddress() != null) {
            dto.setAddress(toAddressDTO(customer.getAddress()));
        }

        if (customer.getUser() != null) {
            dto.setUserId(customer.getUser().getUserId());
            dto.setUsername(customer.getUser().getUsername());
        }

        return dto;
    }

    // 🔹 Map Customer list -> CustomerResponseDTO list
    public static List<CustomerResponseDTO> toCustomerResponseDTOList(List<Customer> customers) {
        return customers.stream()
                        .map(CustomerMapper::toCustomerResponseDTO)
                        .collect(Collectors.toList());
    }

    // 🔹 Map Customer -> PendingCustomerResponseDTO
    public static PendingCustomerResponseDTO toPendingCustomerResponseDTO(Customer customer) {
        if (customer == null) {
            throw new InvalidRequestException("Customer entity is null");
        }

        return new PendingCustomerResponseDTO(
            customer.getCustomerId(),
            customer.getUser() != null ? customer.getUser().getUserId() : null,
            customer.getUser() != null ? customer.getUser().getUsername() : null,
            customer.getStatus()
        );
    }

    // 🔹 Map Customer list -> PendingCustomerResponseDTO list
    public static List<PendingCustomerResponseDTO> toPendingCustomerResponseDTOList(List<Customer> customers) {
        return customers.stream()
                        .map(CustomerMapper::toPendingCustomerResponseDTO)
                        .collect(Collectors.toList());
    }
}
