package com.aurionpro.exception;



import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// Marks this exception with HTTP 400 Bad Request
@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class InvalidInputException extends RuntimeException {

    // Default constructor
    public InvalidInputException() {
        super();
    }

    // Constructor with custom message
    public InvalidInputException(String message) {
        super(message);
    }

    // Constructor with message and cause
    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}

