package com.aurionpro.exception;



import org.springframework.http.HttpStatus;



public class UserApiException extends RuntimeException {
    private HttpStatus status;
    private String message;
}
