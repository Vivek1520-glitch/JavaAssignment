import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("accountId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int accountId = (int) session.getAttribute("accountId");
        int score = 0;
        int totalQuestions = 6;
        String error = req.getParameter("error");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Exam Results</title>");
        out.println("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>");
        out.println("<script>");
        if (error != null) {
            if ("no_retries".equals(error)) {
                out.println("window.onload = function() { alert('Multiple attempts are not allowed!'); };");
            } else if ("database".equals(error)) {
                out.println("window.onload = function() { alert('Database error occurred. Please try again later.'); };");
            }
        }
        out.println("</script>");
        out.println("</head>");
        out.println("<body class='bg-light'>");
        out.println("<div class='container my-5'>");
        out.println("<div class='card shadow-lg p-4'>");
        out.println("<h2 class='mb-4 text-center'>Exam Results</h2>");

        try (Connection conn = DBConnection.getConnection()) {
            @SuppressWarnings("unchecked")
            List<Integer> questionIdList = (List<Integer>) session.getAttribute("questionIdList");
            if (questionIdList == null || questionIdList.size() != totalQuestions) {
                out.println("<div class='alert alert-danger'>Error: Invalid question list. Please start a new exam.</div>");
                out.println("<div class='text-center mt-4'>");
                out.println("<a href='retest' class='btn btn-primary me-2'>Start New Exam</a>");
                out.println("<a href='logout' class='btn btn-danger'>Logout</a>");
                out.println("</div>");
                return;
            }

            out.println("<div class='list-group mb-4'>");
            for (int i = 0; i < questionIdList.size(); i++) {
                int questionId = questionIdList.get(i);
                int questionNumber = i + 1;
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM quiz_questions WHERE question_id = ?");
                ps.setInt(1, questionId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    String question = rs.getString("text");
                    String choiceA = rs.getString("choice_a");
                    String choiceB = rs.getString("choice_b");
                    String choiceC = rs.getString("choice_c");
                    String choiceD = rs.getString("choice_d");
                    String correct = rs.getString("correct_choice");
                    String userAnswer = (String) session.getAttribute("answer_" + questionNumber);

                    boolean isCorrect = correct != null && correct.equalsIgnoreCase(userAnswer);
                    if (isCorrect) {
                        score++;
                    }

                    out.println("<div class='list-group-item mb-3'>");
                    out.println("<h5>Q" + questionNumber + ": " + question + "</h5>");
                    out.println("<ul class='list-unstyled mb-2'>");
                    out.println("<li>A: " + choiceA + "</li>");
                    out.println("<li>B: " + choiceB + "</li>");
                    out.println("<li>C: " + choiceC + "</li>");
                    out.println("<li>D: " + choiceD + "</li>");
                    out.println("</ul>");
                    if (userAnswer == null) {
                        out.println("<p class='text-warning'>You did not answer this question.</p>");
                    } else if (isCorrect) {
                        out.println("<p class='text-success'>✅ Your answer (" + userAnswer + ") is correct!</p>");
                    } else {
                        out.println("<p class='text-danger'>❌ Your answer (" + userAnswer + ") is wrong.</p>");
                        out.println("<p class='text-info'>Correct answer: " + correct + "</p>");
                    }
                    out.println("</div>");
                }
            }
            out.println("</div>");

            double percentage = totalQuestions > 0 ? (score * 100.0) / totalQuestions : 0;
            String grade;
            if (percentage >= 90) grade = "A";
            else if (percentage >= 75) grade = "B";
            else if (percentage >= 60) grade = "C";
            else grade = "D";

            PreparedStatement saveScore = conn.prepareStatement(
                "INSERT INTO attempts(account_id, score, total_questions, attempt_timestamp) VALUES (?, ?, ?, NOW())"
            );
            saveScore.setInt(1, accountId);
            saveScore.setInt(2, score);
            saveScore.setInt(3, totalQuestions);
            saveScore.executeUpdate();

            out.println("<hr>");
            out.println("<h3 class='text-center'>Your Final Score: " + score + " out of " + totalQuestions + "</h3>");
            out.println("<h4 class='text-center'>Percentage: " + String.format("%.2f", percentage) + "%</h4>");
            out.println("<h4 class='text-center'>Grade: " + grade + "</h4>");
            out.println("<div class='text-center mt-4'>");
            out.println("<a href='retest' class='btn btn-primary me-2'>Retest</a>");
            out.println("<a href='leaderboard' class='btn btn-info me-2'>View Leaderboard</a>");
            out.println("<a href='logout' class='btn btn-danger'>Logout</a>");
            out.println("</div>");
        } catch (Exception e) {
            out.println("<div class='alert alert-danger'>Error: " + e.getMessage() + "</div>");
        }
        out.println("</div>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");

        // Clear session attributes to prevent reuse
        session.removeAttribute("questionIdList");
        for (int i = 1; i <= totalQuestions; i++) {
            session.removeAttribute("answer_" + i);
        }
        session.removeAttribute("currentQuestion");
    }
}