import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Enumeration;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/retest")
public class RetestServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("accountId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        String referer = req.getHeader("Referer") != null ? req.getHeader("Referer") : "result";
        String redirectUrl = referer.contains("leaderboard") ? "leaderboard" : "result";

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT allow_retries FROM exam_config WHERE config_id = 1");
            ResultSet rs = ps.executeQuery();
            if (rs.next() && !rs.getBoolean("allow_retries")) {
                PreparedStatement checkAttempt = conn.prepareStatement("SELECT COUNT(*) FROM attempts WHERE account_id = ?");
                checkAttempt.setInt(1, (int) session.getAttribute("accountId"));
                ResultSet attemptRs = checkAttempt.executeQuery();
                if (attemptRs.next() && attemptRs.getInt(1) > 0) {
                    resp.sendRedirect(redirectUrl + "?error=no_retries");
                    return;
                }
            }
        } catch (Exception e) {
            resp.sendRedirect(redirectUrl + "?error=database");
            return;
        }

        Enumeration<String> attrs = session.getAttributeNames();
        while (attrs.hasMoreElements()) {
            String attr = attrs.nextElement();
            if (attr.startsWith("answer_") || attr.equals("currentQuestion") || attr.equals("questionIdList")) {
                session.removeAttribute(attr);
            }
        }

        session.setAttribute("currentQuestion", 1);
        resp.sendRedirect("question");
    }
}