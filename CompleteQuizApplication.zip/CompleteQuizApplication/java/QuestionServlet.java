import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/question")
public class QuestionServlet extends HttpServlet {
    private static final int TOTAL_QUESTIONS = 6;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("accountId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        if (session.getAttribute("currentQuestion") == null) {
            session.setAttribute("currentQuestion", 1);
        }

        int currentQ = (int) session.getAttribute("currentQuestion");

        if (session.getAttribute("questionIdList") == null) {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT question_id FROM quiz_questions ORDER BY RAND() LIMIT ?")) {
                ps.setInt(1, TOTAL_QUESTIONS);
                ResultSet rs = ps.executeQuery();

                List<Integer> questionIdList = new ArrayList<>();
                while (rs.next()) {
                    questionIdList.add(rs.getInt("question_id"));
                }

                if (questionIdList.size() < TOTAL_QUESTIONS) {
                    resp.getWriter().println("Not enough questions in the database.");
                    return;
                }

                session.setAttribute("questionIdList", questionIdList);
            } catch (Exception e) {
                resp.getWriter().println("Database error: " + e.getMessage());
                return;
            }
        }

        if (currentQ < 1 || currentQ > TOTAL_QUESTIONS) {
            resp.sendRedirect("result");
            return;
        }

        renderQuestion(req, resp, null);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("accountId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int currentQ = (int) session.getAttribute("currentQuestion");
        String answer = req.getParameter("answer");
        String action = req.getParameter("action");

        if (action == null) {
            renderQuestion(req, resp, "Invalid action.");
            return;
        }

        if (!"skip".equalsIgnoreCase(action)) {
            if (answer == null || answer.trim().isEmpty()) {
                renderQuestion(req, resp, "Please select an answer before proceeding or choose Skip.");
                return;
            }
            session.setAttribute("answer_" + currentQ, answer.trim());
        }

        if ("next".equalsIgnoreCase(action)) {
            currentQ++;
        } else if ("previous".equalsIgnoreCase(action)) {
            currentQ--;
        } else if ("skip".equalsIgnoreCase(action)) {
            currentQ++;
        }

        session.setAttribute("currentQuestion", currentQ);

        if (currentQ < 1) currentQ = 1;
        if (currentQ > TOTAL_QUESTIONS) {
            resp.sendRedirect("result");
        } else {
            resp.sendRedirect("question");
        }
    }

    private void renderQuestion(HttpServletRequest req, HttpServletResponse resp, String errorMsg) throws IOException {
        HttpSession session = req.getSession(false);
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        int currentQ = (int) session.getAttribute("currentQuestion");
        @SuppressWarnings("unchecked")
        List<Integer> questionIdList = (List<Integer>) session.getAttribute("questionIdList");
        int questionId = questionIdList.get(currentQ - 1);

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM quiz_questions WHERE question_id=?")) {
            ps.setInt(1, questionId);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                resp.sendRedirect("result");
                return;
            }

            String prevAnswer = (String) session.getAttribute("answer_" + currentQ);
            int progressPercent = (int) (((double) currentQ / TOTAL_QUESTIONS) * 100);

            out.println("<!DOCTYPE html>");
            out.println("<html lang='en'>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<title>Question " + currentQ + "</title>");
            out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
            out.println("<style>#timer { font-size: 1.25rem; font-weight: bold; color: #dc3545; }</style>");
            out.println("<script>");
            out.println("let timeLeft = 60;");
            out.println("function startTimer() {");
            out.println("  const timerDisplay = document.getElementById('timer');");
            out.println("  const interval = setInterval(() => {");
            out.println("    if(timeLeft <= 0) {");
            out.println("      clearInterval(interval);");
            out.println("      alert('Time is up! You will be logged out.');");
            out.println("      window.location.href = 'logout';");
            out.println("    } else {");
            out.println("      timerDisplay.textContent = 'Time Left: ' + timeLeft + ' seconds';");
            out.println("      timeLeft--;");
            out.println("    }");
            out.println("  }, 1000);");
            out.println("}");
            out.println("window.onload = startTimer;");
            out.println("</script>");
            out.println("</head>");
            out.println("<body class='bg-light'>");
            out.println("<div class='container mt-5'>");
            out.println("<div class='progress mb-3'>");
            out.println("<div class='progress-bar' role='progressbar' style='width: " + progressPercent + "%;' aria-valuenow='" + progressPercent + "' aria-valuemin='0' aria-valuemax='100'>");
            out.println(progressPercent + "% Completed");
            out.println("</div>");
            out.println("</div>");
            out.println("<div id='timer' class='mb-3 text-center'></div>");

            if (errorMsg != null) {
                out.println("<div class='alert alert-danger text-center mb-3'>" + errorMsg + "</div>");
            }

            out.println("<h4 class='mb-4'>Q" + currentQ + ": " + rs.getString("text") + "</h4>");
            out.println("<form method='post'>");
            out.println("<div class='form-check mb-2'>"
                    + "<input class='form-check-input' type='radio' name='answer' id='choiceA' value='A'"
                    + ("A".equals(prevAnswer) ? " checked" : "") + ">"
                    + "<label class='form-check-label' for='choiceA'>" + rs.getString("choice_a") + "</label>"
                    + "</div>");
            out.println("<div class='form-check mb-2'>"
                    + "<input class='form-check-input' type='radio' name='answer' id='choiceB' value='B'"
                    + ("B".equals(prevAnswer) ? " checked" : "") + ">"
                    + "<label class='form-check-label' for='choiceB'>" + rs.getString("choice_b") + "</label>"
                    + "</div>");
            out.println("<div class='form-check mb-2'>"
                    + "<input class='form-check-input' type='radio' name='answer' id='choiceC' value='C'"
                    + ("C".equals(prevAnswer) ? " checked" : "") + ">"
                    + "<label class='form-check-label' for='choiceC'>" + rs.getString("choice_c") + "</label>"
                    + "</div>");
            out.println("<div class='form-check mb-4'>"
                    + "<input class='form-check-input' type='radio' name='answer' id='choiceD' value='D'"
                    + ("D".equals(prevAnswer) ? " checked" : "") + ">"
                    + "<label class='form-check-label' for='choiceD'>" + rs.getString("choice_d") + "</label>"
                    + "</div>");
            out.println("<div class='d-flex justify-content-between'>");
            if (currentQ > 1) {
                out.println("<button type='submit' name='action' value='previous' class='btn btn-secondary'>&laquo; Previous</button>");
            } else {
                out.println("<div></div>");
            }
            out.println("<button type='submit' name='action' value='skip' class='btn btn-warning'>Skip</button>");
            if (currentQ < TOTAL_QUESTIONS) {
                out.println("<button type='submit' name='action' value='next' class='btn btn-primary'>Next &raquo;</button>");
            } else {
                out.println("<button type='submit' name='action' value='next' class='btn btn-success'>Finish</button>");
            }
            out.println("</div>");
            out.println("</form>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        } catch (Exception e) {
            resp.getWriter().println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}