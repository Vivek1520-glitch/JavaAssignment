import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/leaderboard")
public class LeaderboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("accountId") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        String error = req.getParameter("error");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Leaderboard</title>");
        out.println("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>");
        out.println("<script>");
        if (error != null) {
            if ("no_retries".equals(error)) {
                out.println("window.onload = function() { alert('Multiple attempts are not allowed!'); };");
            } else if ("database".equals(error)) {
                out.println("window.onload = function() { alert('Database error occurred. Please try again later.'); };");
            }
        }
        out.println("</script>");
        out.println("</head>");
        out.println("<body class='bg-light'>");
        out.println("<div class='container my-5'>");
        out.println("<div class='card shadow-lg p-4'>");
        out.println("<h2 class='mb-4 text-center'>Leaderboard</h2>");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT acc.username, MAX(a.score) as top_score, a.total_questions " +
                "FROM attempts a JOIN accounts acc ON a.account_id = acc.account_id " +
                "GROUP BY acc.account_id, acc.username, a.total_questions ORDER BY top_score DESC LIMIT 10"
            );
            ResultSet rs = ps.executeQuery();
            out.println("<table class='table table-striped'>");
            out.println("<thead><tr><th>Rank</th><th>Username</th><th>Top Score</th><th>Total Questions</th></tr></thead>");
            out.println("<tbody>");
            int rank = 1;
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rank++ + "</td>");
                out.println("<td>" + rs.getString("username") + "</td>");
                out.println("<td>" + rs.getInt("top_score") + "</td>");
                out.println("<td>" + rs.getInt("total_questions") + "</td>");
                out.println("</tr>");
            }
            out.println("</tbody>");
            out.println("</table>");
            out.println("<div class='text-center mt-4'>");
            out.println("<a href='question' class='btn btn-primary me-2'>Take Exam</a>");
            out.println("<a href='logout' class='btn btn-danger'>Logout</a>");
            out.println("</div>");
        } catch (Exception e) {
            out.println("<div class='alert alert-danger'>Error: " + e.getMessage() + "</div>");
        }
        out.println("</div>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}