import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addQuestion")
public class AdminAddQuestionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("userType"))) {
            resp.sendRedirect("login.html");
            return;
        }

        String questionText = req.getParameter("questionText");
        String choiceA = req.getParameter("choiceA");
        String choiceB = req.getParameter("choiceB");
        String choiceC = req.getParameter("choiceC");
        String choiceD = req.getParameter("choiceD");
        String correctChoice = req.getParameter("correctChoice");

        if (questionText == null || questionText.isEmpty() ||
            choiceA == null || choiceA.isEmpty() ||
            choiceB == null || choiceB.isEmpty() ||
            choiceC == null || choiceC.isEmpty() ||
            choiceD == null || choiceD.isEmpty() ||
            correctChoice == null || !correctChoice.matches("[A-D]")) {
            resp.sendRedirect("adminDashboard.html?error=invalid_input");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO quiz_questions(text, choice_a, choice_b, choice_c, choice_d, correct_choice) VALUES (?, ?, ?, ?, ?, ?)"
            );
            ps.setString(1, questionText);
            ps.setString(2, choiceA);
            ps.setString(3, choiceB);
            ps.setString(4, choiceC);
            ps.setString(5, choiceD);
            ps.setString(6, correctChoice);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                resp.sendRedirect("adminDashboard.html?success=question_added");
            } else {
                resp.sendRedirect("adminDashboard.html?error=add_failed");
            }
        } catch (Exception e) {
            resp.sendRedirect("adminDashboard.html?error=database");
        }
    }
}