import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/examSettings")
public class AdminQuizSettingsServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("userType"))) {
            resp.sendRedirect("login.html");
            return;
        }

        String allowRetries = req.getParameter("allowRetries");
        boolean allowMultipleAttempts = "true".equalsIgnoreCase(allowRetries);

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE exam_config SET allow_retries = ? WHERE config_id = 1"
            );
            ps.setBoolean(1, allowMultipleAttempts);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                resp.sendRedirect("adminDashboard.html?success=settings_updated");
            } else {
                resp.sendRedirect("adminDashboard.html?error=update_failed");
            }
        } catch (Exception e) {
            resp.sendRedirect("adminDashboard.html?error=database");
        }
    }
}