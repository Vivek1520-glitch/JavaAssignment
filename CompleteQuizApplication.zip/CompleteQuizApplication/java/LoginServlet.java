import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT account_id, user_type FROM accounts WHERE username=? AND password=?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("accountId", rs.getInt("account_id"));
                session.setAttribute("userType", rs.getString("user_type"));
                if ("admin".equals(rs.getString("user_type"))) {
                    resp.sendRedirect("adminDashboard.html");
                } else {
                    session.setAttribute("currentQuestion", 1);
                    resp.sendRedirect("question");
                }
            } else {
                resp.sendRedirect("login.html?error=invalid");
            }
        } catch (Exception e) {
            resp.sendRedirect("login.html?error=database");
        }
    }
}